# This script will upload the parameters to the AWS Parameter Store
$params = (Get-Content 'wfr-al-dev-params.json' | Out-String | ConvertFrom-Json)
foreach ($param in $params.Parameters) {    aws ssm put-parameter --name $param.Name --value $param.Value --type $param.Type --overwrite    }

$params = (Get-Content 'wfr-al-uat-params.json' | Out-String | ConvertFrom-Json)
foreach ($param in $params.Parameters) {    aws ssm put-parameter --name $param.Name --value $param.Value --type $param.Type --overwrite    }
