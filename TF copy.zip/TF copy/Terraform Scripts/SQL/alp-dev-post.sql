
ALTER TABLE [dbo].[AlertDismissals]  WITH CHECK ADD  CONSTRAINT [FK_AlertDismissals_Alerts_AlertId] FOREIGN KEY([AlertId])
REFERENCES [dbo].[Alerts] ([AlertId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[AlertDismissals] CHECK CONSTRAINT [FK_AlertDismissals_Alerts_AlertId]
GO
ALTER TABLE [dbo].[AlertPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_AlertPropertyValues_Alerts_AlertId] FOREIGN KEY([AlertId])
REFERENCES [dbo].[Alerts] ([AlertId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[AlertPropertyValues] CHECK CONSTRAINT [FK_AlertPropertyValues_Alerts_AlertId]
GO
ALTER TABLE [dbo].[AlertPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_AlertPropertyValues_Properties_PropertyId] FOREIGN KEY([PropertyId])
REFERENCES [dbo].[Properties] ([PropertyId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[AlertPropertyValues] CHECK CONSTRAINT [FK_AlertPropertyValues_Properties_PropertyId]
GO
ALTER TABLE [dbo].[AspNetRoleClaims]  WITH CHECK ADD  CONSTRAINT [FK_AspNetRoleClaims_AspNetRoles_RoleId] FOREIGN KEY([RoleId])
REFERENCES [dbo].[AspNetRoles] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[AspNetRoleClaims] CHECK CONSTRAINT [FK_AspNetRoleClaims_AspNetRoles_RoleId]
GO
ALTER TABLE [dbo].[AspNetUserClaims]  WITH CHECK ADD  CONSTRAINT [FK_AspNetUserClaims_AspNetUsers_UserId] FOREIGN KEY([UserId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[AspNetUserClaims] CHECK CONSTRAINT [FK_AspNetUserClaims_AspNetUsers_UserId]
GO
ALTER TABLE [dbo].[AspNetUserLogins]  WITH CHECK ADD  CONSTRAINT [FK_AspNetUserLogins_AspNetUsers_UserId] FOREIGN KEY([UserId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[AspNetUserLogins] CHECK CONSTRAINT [FK_AspNetUserLogins_AspNetUsers_UserId]
GO
ALTER TABLE [dbo].[AspNetUserRoles]  WITH CHECK ADD  CONSTRAINT [FK_AspNetUserRoles_AspNetRoles_RoleId] FOREIGN KEY([RoleId])
REFERENCES [dbo].[AspNetRoles] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[AspNetUserRoles] CHECK CONSTRAINT [FK_AspNetUserRoles_AspNetRoles_RoleId]
GO
ALTER TABLE [dbo].[AspNetUserRoles]  WITH CHECK ADD  CONSTRAINT [FK_AspNetUserRoles_AspNetUsers_UserId] FOREIGN KEY([UserId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[AspNetUserRoles] CHECK CONSTRAINT [FK_AspNetUserRoles_AspNetUsers_UserId]
GO
ALTER TABLE [dbo].[AspNetUserTokens]  WITH CHECK ADD  CONSTRAINT [FK_AspNetUserTokens_AspNetUsers_UserId] FOREIGN KEY([UserId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[AspNetUserTokens] CHECK CONSTRAINT [FK_AspNetUserTokens_AspNetUsers_UserId]
GO
ALTER TABLE [dbo].[AwardRecordPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_AwardRecordPropertyValues_AwardRecords_AwardRecordId] FOREIGN KEY([AwardRecordId])
REFERENCES [dbo].[AwardRecords] ([AwardRecordId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[AwardRecordPropertyValues] CHECK CONSTRAINT [FK_AwardRecordPropertyValues_AwardRecords_AwardRecordId]
GO
ALTER TABLE [dbo].[AwardRecordPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_AwardRecordPropertyValues_Properties_PropertyId] FOREIGN KEY([PropertyId])
REFERENCES [dbo].[Properties] ([PropertyId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[AwardRecordPropertyValues] CHECK CONSTRAINT [FK_AwardRecordPropertyValues_Properties_PropertyId]
GO
ALTER TABLE [dbo].[AwardRecords]  WITH CHECK ADD  CONSTRAINT [FK_AwardRecords_AspNetUsers_PrimaryEntityId] FOREIGN KEY([PrimaryEntityId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[AwardRecords] CHECK CONSTRAINT [FK_AwardRecords_AspNetUsers_PrimaryEntityId]
GO
ALTER TABLE [dbo].[CareerLatticeRecordPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_CareerLatticeRecordPropertyValues_CareerLatticeRecords_CareerLatticeRecordId] FOREIGN KEY([CareerLatticeRecordId])
REFERENCES [dbo].[CareerLatticeRecords] ([CareerLatticeRecordId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[CareerLatticeRecordPropertyValues] CHECK CONSTRAINT [FK_CareerLatticeRecordPropertyValues_CareerLatticeRecords_CareerLatticeRecordId]
GO
ALTER TABLE [dbo].[CareerLatticeRecordPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_CareerLatticeRecordPropertyValues_Properties_PropertyId] FOREIGN KEY([PropertyId])
REFERENCES [dbo].[Properties] ([PropertyId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[CareerLatticeRecordPropertyValues] CHECK CONSTRAINT [FK_CareerLatticeRecordPropertyValues_Properties_PropertyId]
GO
ALTER TABLE [dbo].[CareerLatticeRecords]  WITH CHECK ADD  CONSTRAINT [FK_CareerLatticeRecords_AspNetUsers_PrimaryEntityId] FOREIGN KEY([PrimaryEntityId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[CareerLatticeRecords] CHECK CONSTRAINT [FK_CareerLatticeRecords_AspNetUsers_PrimaryEntityId]
GO
ALTER TABLE [dbo].[CertificationRecordPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_CertificationRecordPropertyValues_CertificationRecords_CertificationRecordId] FOREIGN KEY([CertificationRecordId])
REFERENCES [dbo].[CertificationRecords] ([CertificationRecordId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[CertificationRecordPropertyValues] CHECK CONSTRAINT [FK_CertificationRecordPropertyValues_CertificationRecords_CertificationRecordId]
GO
ALTER TABLE [dbo].[CertificationRecordPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_CertificationRecordPropertyValues_Properties_PropertyId] FOREIGN KEY([PropertyId])
REFERENCES [dbo].[Properties] ([PropertyId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[CertificationRecordPropertyValues] CHECK CONSTRAINT [FK_CertificationRecordPropertyValues_Properties_PropertyId]
GO
ALTER TABLE [dbo].[CertificationRecords]  WITH CHECK ADD  CONSTRAINT [FK_CertificationRecords_AspNetUsers_PrimaryEntityId] FOREIGN KEY([PrimaryEntityId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[CertificationRecords] CHECK CONSTRAINT [FK_CertificationRecords_AspNetUsers_PrimaryEntityId]
GO
ALTER TABLE [dbo].[CertRules]  WITH CHECK ADD  CONSTRAINT [FK_CertRules_Rules_RuleId] FOREIGN KEY([RuleId])
REFERENCES [dbo].[Rules] ([RuleId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[CertRules] CHECK CONSTRAINT [FK_CertRules_Rules_RuleId]
GO
ALTER TABLE [dbo].[CoachRelationshipActions]  WITH CHECK ADD  CONSTRAINT [FK_CoachRelationshipActions_AspNetUsers_CoachId] FOREIGN KEY([CoachId])
REFERENCES [dbo].[AspNetUsers] ([Id])
GO
ALTER TABLE [dbo].[CoachRelationshipActions] CHECK CONSTRAINT [FK_CoachRelationshipActions_AspNetUsers_CoachId]
GO
ALTER TABLE [dbo].[CoachRelationshipActions]  WITH CHECK ADD  CONSTRAINT [FK_CoachRelationshipActions_AspNetUsers_PrimaryEntityId] FOREIGN KEY([PrimaryEntityId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[CoachRelationshipActions] CHECK CONSTRAINT [FK_CoachRelationshipActions_AspNetUsers_PrimaryEntityId]
GO
ALTER TABLE [dbo].[CoachRelationshipActions]  WITH CHECK ADD  CONSTRAINT [FK_CoachRelationshipActions_CoachRelationships_CoachRelationshipId] FOREIGN KEY([CoachRelationshipId])
REFERENCES [dbo].[CoachRelationships] ([CoachRelationshipId])
GO
ALTER TABLE [dbo].[CoachRelationshipActions] CHECK CONSTRAINT [FK_CoachRelationshipActions_CoachRelationships_CoachRelationshipId]
GO
ALTER TABLE [dbo].[CoachRelationships]  WITH CHECK ADD  CONSTRAINT [FK_CoachRelationships_AspNetUsers_CoachId] FOREIGN KEY([CoachId])
REFERENCES [dbo].[AspNetUsers] ([Id])
GO
ALTER TABLE [dbo].[CoachRelationships] CHECK CONSTRAINT [FK_CoachRelationships_AspNetUsers_CoachId]
GO
ALTER TABLE [dbo].[CoachRelationships]  WITH CHECK ADD  CONSTRAINT [FK_CoachRelationships_AspNetUsers_PrimaryEntityId] FOREIGN KEY([PrimaryEntityId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[CoachRelationships] CHECK CONSTRAINT [FK_CoachRelationships_AspNetUsers_PrimaryEntityId]
GO
ALTER TABLE [dbo].[CommentPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_CommentPropertyValues_Comments_CommentId] FOREIGN KEY([CommentId])
REFERENCES [dbo].[Comments] ([CommentId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[CommentPropertyValues] CHECK CONSTRAINT [FK_CommentPropertyValues_Comments_CommentId]
GO
ALTER TABLE [dbo].[CommentPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_CommentPropertyValues_Properties_PropertyId] FOREIGN KEY([PropertyId])
REFERENCES [dbo].[Properties] ([PropertyId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[CommentPropertyValues] CHECK CONSTRAINT [FK_CommentPropertyValues_Properties_PropertyId]
GO
ALTER TABLE [dbo].[Comments]  WITH CHECK ADD  CONSTRAINT [FK_Comments_AspNetUsers_PrimaryEntityId] FOREIGN KEY([PrimaryEntityId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Comments] CHECK CONSTRAINT [FK_Comments_AspNetUsers_PrimaryEntityId]
GO
ALTER TABLE [dbo].[Comments]  WITH CHECK ADD  CONSTRAINT [FK_Comments_EntityTypes_EntityTypeId] FOREIGN KEY([EntityTypeId])
REFERENCES [dbo].[EntityTypes] ([EntityTypeId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Comments] CHECK CONSTRAINT [FK_Comments_EntityTypes_EntityTypeId]
GO
ALTER TABLE [dbo].[CommunityServiceRecordPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_CommunityServiceRecordPropertyValues_CommunityServiceRecords_CommunityServiceRecordId] FOREIGN KEY([CommunityServiceRecordId])
REFERENCES [dbo].[CommunityServiceRecords] ([CommunityServiceRecordId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[CommunityServiceRecordPropertyValues] CHECK CONSTRAINT [FK_CommunityServiceRecordPropertyValues_CommunityServiceRecords_CommunityServiceRecordId]
GO
ALTER TABLE [dbo].[CommunityServiceRecordPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_CommunityServiceRecordPropertyValues_Properties_PropertyId] FOREIGN KEY([PropertyId])
REFERENCES [dbo].[Properties] ([PropertyId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[CommunityServiceRecordPropertyValues] CHECK CONSTRAINT [FK_CommunityServiceRecordPropertyValues_Properties_PropertyId]
GO
ALTER TABLE [dbo].[CommunityServiceRecords]  WITH CHECK ADD  CONSTRAINT [FK_CommunityServiceRecords_AspNetUsers_PrimaryEntityId] FOREIGN KEY([PrimaryEntityId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[CommunityServiceRecords] CHECK CONSTRAINT [FK_CommunityServiceRecords_AspNetUsers_PrimaryEntityId]
GO
ALTER TABLE [dbo].[CourseMeetingRecordPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_CourseMeetingRecordPropertyValues_CourseMeetingRecords_CourseMeetingRecordId] FOREIGN KEY([CourseMeetingRecordId])
REFERENCES [dbo].[CourseMeetingRecords] ([CourseMeetingRecordId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[CourseMeetingRecordPropertyValues] CHECK CONSTRAINT [FK_CourseMeetingRecordPropertyValues_CourseMeetingRecords_CourseMeetingRecordId]
GO
ALTER TABLE [dbo].[CourseMeetingRecordPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_CourseMeetingRecordPropertyValues_Properties_PropertyId] FOREIGN KEY([PropertyId])
REFERENCES [dbo].[Properties] ([PropertyId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[CourseMeetingRecordPropertyValues] CHECK CONSTRAINT [FK_CourseMeetingRecordPropertyValues_Properties_PropertyId]
GO
ALTER TABLE [dbo].[CourseMeetingRecords]  WITH CHECK ADD  CONSTRAINT [FK_CourseMeetingRecords_CourseSectionRecords_CourseSectionRecordId] FOREIGN KEY([CourseSectionRecordId])
REFERENCES [dbo].[CourseSectionRecords] ([CourseSectionRecordId])
GO
ALTER TABLE [dbo].[CourseMeetingRecords] CHECK CONSTRAINT [FK_CourseMeetingRecords_CourseSectionRecords_CourseSectionRecordId]
GO
ALTER TABLE [dbo].[CourseRecordPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_CourseRecordPropertyValues_CourseRecords_CourseRecordId] FOREIGN KEY([CourseRecordId])
REFERENCES [dbo].[CourseRecords] ([CourseRecordId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[CourseRecordPropertyValues] CHECK CONSTRAINT [FK_CourseRecordPropertyValues_CourseRecords_CourseRecordId]
GO
ALTER TABLE [dbo].[CourseRecordPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_CourseRecordPropertyValues_Properties_PropertyId] FOREIGN KEY([PropertyId])
REFERENCES [dbo].[Properties] ([PropertyId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[CourseRecordPropertyValues] CHECK CONSTRAINT [FK_CourseRecordPropertyValues_Properties_PropertyId]
GO
ALTER TABLE [dbo].[CourseRecords]  WITH CHECK ADD  CONSTRAINT [FK_CourseRecords_AspNetUsers_CourseOwnerId] FOREIGN KEY([CourseOwnerId])
REFERENCES [dbo].[AspNetUsers] ([Id])
GO
ALTER TABLE [dbo].[CourseRecords] CHECK CONSTRAINT [FK_CourseRecords_AspNetUsers_CourseOwnerId]
GO
ALTER TABLE [dbo].[CourseSectionRecordPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_CourseSectionRecordPropertyValues_CourseSectionRecords_CourseSectionRecordId] FOREIGN KEY([CourseSectionRecordId])
REFERENCES [dbo].[CourseSectionRecords] ([CourseSectionRecordId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[CourseSectionRecordPropertyValues] CHECK CONSTRAINT [FK_CourseSectionRecordPropertyValues_CourseSectionRecords_CourseSectionRecordId]
GO
ALTER TABLE [dbo].[CourseSectionRecordPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_CourseSectionRecordPropertyValues_Properties_PropertyId] FOREIGN KEY([PropertyId])
REFERENCES [dbo].[Properties] ([PropertyId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[CourseSectionRecordPropertyValues] CHECK CONSTRAINT [FK_CourseSectionRecordPropertyValues_Properties_PropertyId]
GO
ALTER TABLE [dbo].[CourseSectionRecords]  WITH CHECK ADD  CONSTRAINT [FK_CourseSectionRecords_AspNetUsers_CourseSectionOwnerId] FOREIGN KEY([CourseSectionOwnerId])
REFERENCES [dbo].[AspNetUsers] ([Id])
GO
ALTER TABLE [dbo].[CourseSectionRecords] CHECK CONSTRAINT [FK_CourseSectionRecords_AspNetUsers_CourseSectionOwnerId]
GO
ALTER TABLE [dbo].[CourseSectionRecords]  WITH CHECK ADD  CONSTRAINT [FK_CourseSectionRecords_CourseRecords_CourseRecordId] FOREIGN KEY([CourseRecordId])
REFERENCES [dbo].[CourseRecords] ([CourseRecordId])
GO
ALTER TABLE [dbo].[CourseSectionRecords] CHECK CONSTRAINT [FK_CourseSectionRecords_CourseRecords_CourseRecordId]
GO
ALTER TABLE [dbo].[EducationRecordPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_EducationRecordPropertyValues_EducationRecords_EducationRecordId] FOREIGN KEY([EducationRecordId])
REFERENCES [dbo].[EducationRecords] ([EducationRecordId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[EducationRecordPropertyValues] CHECK CONSTRAINT [FK_EducationRecordPropertyValues_EducationRecords_EducationRecordId]
GO
ALTER TABLE [dbo].[EducationRecordPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_EducationRecordPropertyValues_Properties_PropertyId] FOREIGN KEY([PropertyId])
REFERENCES [dbo].[Properties] ([PropertyId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[EducationRecordPropertyValues] CHECK CONSTRAINT [FK_EducationRecordPropertyValues_Properties_PropertyId]
GO
ALTER TABLE [dbo].[EducationRecords]  WITH CHECK ADD  CONSTRAINT [FK_EducationRecords_AspNetUsers_PrimaryEntityId] FOREIGN KEY([PrimaryEntityId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[EducationRecords] CHECK CONSTRAINT [FK_EducationRecords_AspNetUsers_PrimaryEntityId]
GO
ALTER TABLE [dbo].[EduRules]  WITH CHECK ADD  CONSTRAINT [FK_EduRules_Rules_RuleId] FOREIGN KEY([RuleId])
REFERENCES [dbo].[Rules] ([RuleId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[EduRules] CHECK CONSTRAINT [FK_EduRules_Rules_RuleId]
GO
ALTER TABLE [dbo].[EmploymentRecordPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_EmploymentRecordPropertyValues_EmploymentRecords_EmploymentRecordId] FOREIGN KEY([EmploymentRecordId])
REFERENCES [dbo].[EmploymentRecords] ([EmploymentRecordId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[EmploymentRecordPropertyValues] CHECK CONSTRAINT [FK_EmploymentRecordPropertyValues_EmploymentRecords_EmploymentRecordId]
GO
ALTER TABLE [dbo].[EmploymentRecordPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_EmploymentRecordPropertyValues_Properties_PropertyId] FOREIGN KEY([PropertyId])
REFERENCES [dbo].[Properties] ([PropertyId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[EmploymentRecordPropertyValues] CHECK CONSTRAINT [FK_EmploymentRecordPropertyValues_Properties_PropertyId]
GO
ALTER TABLE [dbo].[EmploymentRecords]  WITH CHECK ADD  CONSTRAINT [FK_EmploymentRecords_AspNetUsers_PrimaryEntityId] FOREIGN KEY([PrimaryEntityId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[EmploymentRecords] CHECK CONSTRAINT [FK_EmploymentRecords_AspNetUsers_PrimaryEntityId]
GO
ALTER TABLE [dbo].[EnrollmentActions]  WITH CHECK ADD  CONSTRAINT [FK_EnrollmentActions_EnrollmentRecords_EnrollmentRecordId] FOREIGN KEY([EnrollmentRecordId])
REFERENCES [dbo].[EnrollmentRecords] ([EnrollmentRecordId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[EnrollmentActions] CHECK CONSTRAINT [FK_EnrollmentActions_EnrollmentRecords_EnrollmentRecordId]
GO
ALTER TABLE [dbo].[EnrollmentRecordPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_EnrollmentRecordPropertyValues_EnrollmentRecords_EnrollmentRecordId] FOREIGN KEY([EnrollmentRecordId])
REFERENCES [dbo].[EnrollmentRecords] ([EnrollmentRecordId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[EnrollmentRecordPropertyValues] CHECK CONSTRAINT [FK_EnrollmentRecordPropertyValues_EnrollmentRecords_EnrollmentRecordId]
GO
ALTER TABLE [dbo].[EnrollmentRecordPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_EnrollmentRecordPropertyValues_Properties_PropertyId] FOREIGN KEY([PropertyId])
REFERENCES [dbo].[Properties] ([PropertyId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[EnrollmentRecordPropertyValues] CHECK CONSTRAINT [FK_EnrollmentRecordPropertyValues_Properties_PropertyId]
GO
ALTER TABLE [dbo].[EnrollmentRecords]  WITH CHECK ADD  CONSTRAINT [FK_EnrollmentRecords_AspNetUsers_PrimaryEntityId] FOREIGN KEY([PrimaryEntityId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[EnrollmentRecords] CHECK CONSTRAINT [FK_EnrollmentRecords_AspNetUsers_PrimaryEntityId]
GO
ALTER TABLE [dbo].[EnrollmentRecords]  WITH CHECK ADD  CONSTRAINT [FK_EnrollmentRecords_CourseSectionRecords_CourseSectionRecordId] FOREIGN KEY([CourseSectionRecordId])
REFERENCES [dbo].[CourseSectionRecords] ([CourseSectionRecordId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[EnrollmentRecords] CHECK CONSTRAINT [FK_EnrollmentRecords_CourseSectionRecords_CourseSectionRecordId]
GO
ALTER TABLE [dbo].[EntityTypeProperties]  WITH CHECK ADD  CONSTRAINT [FK_EntityTypeProperties_EntityTypes_EntityTypeId] FOREIGN KEY([EntityTypeId])
REFERENCES [dbo].[EntityTypes] ([EntityTypeId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[EntityTypeProperties] CHECK CONSTRAINT [FK_EntityTypeProperties_EntityTypes_EntityTypeId]
GO
ALTER TABLE [dbo].[EntityTypeProperties]  WITH CHECK ADD  CONSTRAINT [FK_EntityTypeProperties_Properties_PropertyId] FOREIGN KEY([PropertyId])
REFERENCES [dbo].[Properties] ([PropertyId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[EntityTypeProperties] CHECK CONSTRAINT [FK_EntityTypeProperties_Properties_PropertyId]
GO
ALTER TABLE [dbo].[FeedbackRecordPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_FeedbackRecordPropertyValues_FeedbackRecords_FeedbackRecordId] FOREIGN KEY([FeedbackRecordId])
REFERENCES [dbo].[FeedbackRecords] ([FeedbackRecordId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[FeedbackRecordPropertyValues] CHECK CONSTRAINT [FK_FeedbackRecordPropertyValues_FeedbackRecords_FeedbackRecordId]
GO
ALTER TABLE [dbo].[FeedbackRecordPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_FeedbackRecordPropertyValues_Properties_PropertyId] FOREIGN KEY([PropertyId])
REFERENCES [dbo].[Properties] ([PropertyId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[FeedbackRecordPropertyValues] CHECK CONSTRAINT [FK_FeedbackRecordPropertyValues_Properties_PropertyId]
GO
ALTER TABLE [dbo].[FeedbackRecords]  WITH CHECK ADD  CONSTRAINT [FK_FeedbackRecords_AspNetUsers_PrimaryEntityId] FOREIGN KEY([PrimaryEntityId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[FeedbackRecords] CHECK CONSTRAINT [FK_FeedbackRecords_AspNetUsers_PrimaryEntityId]
GO
ALTER TABLE [dbo].[FileInfo]  WITH CHECK ADD  CONSTRAINT [FK_FileInfo_EntityTypeProperties_EntityTypePropertyId] FOREIGN KEY([EntityTypePropertyId])
REFERENCES [dbo].[EntityTypeProperties] ([EntityTypePropertyId])
GO
ALTER TABLE [dbo].[FileInfo] CHECK CONSTRAINT [FK_FileInfo_EntityTypeProperties_EntityTypePropertyId]
GO
ALTER TABLE [dbo].[FormElementChoiceGroups]  WITH CHECK ADD  CONSTRAINT [FK_FormElementChoiceGroups_FormElements_FormElementId] FOREIGN KEY([FormElementId])
REFERENCES [dbo].[FormElements] ([FormElementId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[FormElementChoiceGroups] CHECK CONSTRAINT [FK_FormElementChoiceGroups_FormElements_FormElementId]
GO
ALTER TABLE [dbo].[FormElementChoices]  WITH CHECK ADD  CONSTRAINT [FK_FormElementChoices_FormElements_FormElementId] FOREIGN KEY([FormElementId])
REFERENCES [dbo].[FormElements] ([FormElementId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[FormElementChoices] CHECK CONSTRAINT [FK_FormElementChoices_FormElements_FormElementId]
GO
ALTER TABLE [dbo].[FormElementChoices]  WITH CHECK ADD  CONSTRAINT [FK_FormElementChoices_PropertyChoices_PropertyChoiceId] FOREIGN KEY([PropertyChoiceId])
REFERENCES [dbo].[PropertyChoices] ([PropertyChoiceId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[FormElementChoices] CHECK CONSTRAINT [FK_FormElementChoices_PropertyChoices_PropertyChoiceId]
GO
ALTER TABLE [dbo].[FormElementProperties]  WITH CHECK ADD  CONSTRAINT [FK_FormElementProperties_FormElements_FormElementId] FOREIGN KEY([FormElementId])
REFERENCES [dbo].[FormElements] ([FormElementId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[FormElementProperties] CHECK CONSTRAINT [FK_FormElementProperties_FormElements_FormElementId]
GO
ALTER TABLE [dbo].[FormElementProperties]  WITH CHECK ADD  CONSTRAINT [FK_FormElementProperties_Properties_PropertyId] FOREIGN KEY([PropertyId])
REFERENCES [dbo].[Properties] ([PropertyId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[FormElementProperties] CHECK CONSTRAINT [FK_FormElementProperties_Properties_PropertyId]
GO
ALTER TABLE [dbo].[FormElements]  WITH CHECK ADD  CONSTRAINT [FK_FormElements_FormElementSubTypes_FormElementSubTypeId] FOREIGN KEY([FormElementSubTypeId])
REFERENCES [dbo].[FormElementSubTypes] ([FormElementSubTypeId])
GO
ALTER TABLE [dbo].[FormElements] CHECK CONSTRAINT [FK_FormElements_FormElementSubTypes_FormElementSubTypeId]
GO
ALTER TABLE [dbo].[FormElements]  WITH CHECK ADD  CONSTRAINT [FK_FormElements_FormElementTypes_FormElementTypeId] FOREIGN KEY([FormElementTypeId])
REFERENCES [dbo].[FormElementTypes] ([FormElementTypeId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[FormElements] CHECK CONSTRAINT [FK_FormElements_FormElementTypes_FormElementTypeId]
GO
ALTER TABLE [dbo].[FormElements]  WITH CHECK ADD  CONSTRAINT [FK_FormElements_Forms_FormId] FOREIGN KEY([FormId])
REFERENCES [dbo].[Forms] ([FormId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[FormElements] CHECK CONSTRAINT [FK_FormElements_Forms_FormId]
GO
ALTER TABLE [dbo].[FormElementSubTypes]  WITH CHECK ADD  CONSTRAINT [FK_FormElementSubTypes_FormElementTypes_FormElementTypeId] FOREIGN KEY([FormElementTypeId])
REFERENCES [dbo].[FormElementTypes] ([FormElementTypeId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[FormElementSubTypes] CHECK CONSTRAINT [FK_FormElementSubTypes_FormElementTypes_FormElementTypeId]
GO
ALTER TABLE [dbo].[FormResponseLogs]  WITH CHECK ADD  CONSTRAINT [FK_FormResponseLogs_Forms_FormId] FOREIGN KEY([FormId])
REFERENCES [dbo].[Forms] ([FormId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[FormResponseLogs] CHECK CONSTRAINT [FK_FormResponseLogs_Forms_FormId]
GO
ALTER TABLE [dbo].[LoginHistories]  WITH CHECK ADD  CONSTRAINT [FK_LoginHistories_AspNetUsers_UserId] FOREIGN KEY([UserId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[LoginHistories] CHECK CONSTRAINT [FK_LoginHistories_AspNetUsers_UserId]
GO
ALTER TABLE [dbo].[MembershipRecordPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_MembershipRecordPropertyValues_MembershipRecords_MembershipRecordId] FOREIGN KEY([MembershipRecordId])
REFERENCES [dbo].[MembershipRecords] ([MembershipRecordId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[MembershipRecordPropertyValues] CHECK CONSTRAINT [FK_MembershipRecordPropertyValues_MembershipRecords_MembershipRecordId]
GO
ALTER TABLE [dbo].[MembershipRecordPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_MembershipRecordPropertyValues_Properties_PropertyId] FOREIGN KEY([PropertyId])
REFERENCES [dbo].[Properties] ([PropertyId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[MembershipRecordPropertyValues] CHECK CONSTRAINT [FK_MembershipRecordPropertyValues_Properties_PropertyId]
GO
ALTER TABLE [dbo].[MembershipRecords]  WITH CHECK ADD  CONSTRAINT [FK_MembershipRecords_AspNetUsers_PrimaryEntityId] FOREIGN KEY([PrimaryEntityId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[MembershipRecords] CHECK CONSTRAINT [FK_MembershipRecords_AspNetUsers_PrimaryEntityId]
GO
ALTER TABLE [dbo].[Notifications]  WITH CHECK ADD  CONSTRAINT [FK_Notifications_AspNetUsers_UserId] FOREIGN KEY([UserId])
REFERENCES [dbo].[AspNetUsers] ([Id])
GO
ALTER TABLE [dbo].[Notifications] CHECK CONSTRAINT [FK_Notifications_AspNetUsers_UserId]
GO
ALTER TABLE [dbo].[Notifications]  WITH CHECK ADD  CONSTRAINT [FK_Notifications_MessageContents_MessageContentId] FOREIGN KEY([MessageContentId])
REFERENCES [dbo].[MessageContents] ([MessageContentId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Notifications] CHECK CONSTRAINT [FK_Notifications_MessageContents_MessageContentId]
GO
ALTER TABLE [dbo].[NotificationTriggers]  WITH CHECK ADD  CONSTRAINT [FK_NotificationTriggers_AspNetRoles_RoleId] FOREIGN KEY([RoleId])
REFERENCES [dbo].[AspNetRoles] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[NotificationTriggers] CHECK CONSTRAINT [FK_NotificationTriggers_AspNetRoles_RoleId]
GO
ALTER TABLE [dbo].[NotificationTriggers]  WITH CHECK ADD  CONSTRAINT [FK_NotificationTriggers_NotificationTemplates_TemplateNotificationTemplateId] FOREIGN KEY([TemplateNotificationTemplateId])
REFERENCES [dbo].[NotificationTemplates] ([NotificationTemplateId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[NotificationTriggers] CHECK CONSTRAINT [FK_NotificationTriggers_NotificationTemplates_TemplateNotificationTemplateId]
GO
ALTER TABLE [dbo].[OrganizationPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_OrganizationPropertyValues_Organizations_OrganizationId] FOREIGN KEY([OrganizationId])
REFERENCES [dbo].[Organizations] ([OrganizationId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[OrganizationPropertyValues] CHECK CONSTRAINT [FK_OrganizationPropertyValues_Organizations_OrganizationId]
GO
ALTER TABLE [dbo].[OrganizationPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_OrganizationPropertyValues_Properties_PropertyId] FOREIGN KEY([PropertyId])
REFERENCES [dbo].[Properties] ([PropertyId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[OrganizationPropertyValues] CHECK CONSTRAINT [FK_OrganizationPropertyValues_Properties_PropertyId]
GO
ALTER TABLE [dbo].[PDPGoalRecordPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_PDPGoalRecordPropertyValues_PDPGoalRecords_PDPGoalRecordId] FOREIGN KEY([PDPGoalRecordId])
REFERENCES [dbo].[PDPGoalRecords] ([PDPGoalRecordId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[PDPGoalRecordPropertyValues] CHECK CONSTRAINT [FK_PDPGoalRecordPropertyValues_PDPGoalRecords_PDPGoalRecordId]
GO
ALTER TABLE [dbo].[PDPGoalRecordPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_PDPGoalRecordPropertyValues_Properties_PropertyId] FOREIGN KEY([PropertyId])
REFERENCES [dbo].[Properties] ([PropertyId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[PDPGoalRecordPropertyValues] CHECK CONSTRAINT [FK_PDPGoalRecordPropertyValues_Properties_PropertyId]
GO
ALTER TABLE [dbo].[PDPGoalRecords]  WITH CHECK ADD  CONSTRAINT [FK_PDPGoalRecords_AspNetUsers_PrimaryEntityId] FOREIGN KEY([PrimaryEntityId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[PDPGoalRecords] CHECK CONSTRAINT [FK_PDPGoalRecords_AspNetUsers_PrimaryEntityId]
GO
ALTER TABLE [dbo].[PDPRequiredTrainingRecordPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_PDPRequiredTrainingRecordPropertyValues_PDPRequiredTrainingRecords_PDPRequiredTrainingRecordId] FOREIGN KEY([PDPRequiredTrainingRecordId])
REFERENCES [dbo].[PDPRequiredTrainingRecords] ([PDPRequiredTrainingRecordId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[PDPRequiredTrainingRecordPropertyValues] CHECK CONSTRAINT [FK_PDPRequiredTrainingRecordPropertyValues_PDPRequiredTrainingRecords_PDPRequiredTrainingRecordId]
GO
ALTER TABLE [dbo].[PDPRequiredTrainingRecordPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_PDPRequiredTrainingRecordPropertyValues_Properties_PropertyId] FOREIGN KEY([PropertyId])
REFERENCES [dbo].[Properties] ([PropertyId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[PDPRequiredTrainingRecordPropertyValues] CHECK CONSTRAINT [FK_PDPRequiredTrainingRecordPropertyValues_Properties_PropertyId]
GO
ALTER TABLE [dbo].[PDPRequiredTrainingRecords]  WITH CHECK ADD  CONSTRAINT [FK_PDPRequiredTrainingRecords_AspNetUsers_PrimaryEntityId] FOREIGN KEY([PrimaryEntityId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[PDPRequiredTrainingRecords] CHECK CONSTRAINT [FK_PDPRequiredTrainingRecords_AspNetUsers_PrimaryEntityId]
GO
ALTER TABLE [dbo].[PDPSelfAssessmentRecordPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_PDPSelfAssessmentRecordPropertyValues_PDPSelfAssessmentRecords_PDPSelfAssessmentRecordId] FOREIGN KEY([PDPSelfAssessmentRecordId])
REFERENCES [dbo].[PDPSelfAssessmentRecords] ([PDPSelfAssessmentRecordId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[PDPSelfAssessmentRecordPropertyValues] CHECK CONSTRAINT [FK_PDPSelfAssessmentRecordPropertyValues_PDPSelfAssessmentRecords_PDPSelfAssessmentRecordId]
GO
ALTER TABLE [dbo].[PDPSelfAssessmentRecordPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_PDPSelfAssessmentRecordPropertyValues_Properties_PropertyId] FOREIGN KEY([PropertyId])
REFERENCES [dbo].[Properties] ([PropertyId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[PDPSelfAssessmentRecordPropertyValues] CHECK CONSTRAINT [FK_PDPSelfAssessmentRecordPropertyValues_Properties_PropertyId]
GO
ALTER TABLE [dbo].[PDPSelfAssessmentRecords]  WITH CHECK ADD  CONSTRAINT [FK_PDPSelfAssessmentRecords_AspNetUsers_PrimaryEntityId] FOREIGN KEY([PrimaryEntityId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[PDPSelfAssessmentRecords] CHECK CONSTRAINT [FK_PDPSelfAssessmentRecords_AspNetUsers_PrimaryEntityId]
GO
ALTER TABLE [dbo].[Properties]  WITH CHECK ADD  CONSTRAINT [FK_Properties_PropertySubTypes_PropertySubTypeId] FOREIGN KEY([PropertySubTypeId])
REFERENCES [dbo].[PropertySubTypes] ([PropertySubTypeId])
GO
ALTER TABLE [dbo].[Properties] CHECK CONSTRAINT [FK_Properties_PropertySubTypes_PropertySubTypeId]
GO
ALTER TABLE [dbo].[Properties]  WITH CHECK ADD  CONSTRAINT [FK_Properties_PropertyTypes_PropertyTypeId] FOREIGN KEY([PropertyTypeId])
REFERENCES [dbo].[PropertyTypes] ([PropertyTypeId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Properties] CHECK CONSTRAINT [FK_Properties_PropertyTypes_PropertyTypeId]
GO
ALTER TABLE [dbo].[PropertyChoices]  WITH CHECK ADD  CONSTRAINT [FK_PropertyChoices_Properties_PropertyId] FOREIGN KEY([PropertyId])
REFERENCES [dbo].[Properties] ([PropertyId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[PropertyChoices] CHECK CONSTRAINT [FK_PropertyChoices_Properties_PropertyId]
GO
ALTER TABLE [dbo].[PropertySubTypes]  WITH CHECK ADD  CONSTRAINT [FK_PropertySubTypes_PropertyTypes_PropertyTypeId] FOREIGN KEY([PropertyTypeId])
REFERENCES [dbo].[PropertyTypes] ([PropertyTypeId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[PropertySubTypes] CHECK CONSTRAINT [FK_PropertySubTypes_PropertyTypes_PropertyTypeId]
GO
ALTER TABLE [dbo].[ReferenceRecordPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_ReferenceRecordPropertyValues_Properties_PropertyId] FOREIGN KEY([PropertyId])
REFERENCES [dbo].[Properties] ([PropertyId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ReferenceRecordPropertyValues] CHECK CONSTRAINT [FK_ReferenceRecordPropertyValues_Properties_PropertyId]
GO
ALTER TABLE [dbo].[ReferenceRecordPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_ReferenceRecordPropertyValues_ReferenceRecords_ReferenceRecordId] FOREIGN KEY([ReferenceRecordId])
REFERENCES [dbo].[ReferenceRecords] ([ReferenceRecordId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ReferenceRecordPropertyValues] CHECK CONSTRAINT [FK_ReferenceRecordPropertyValues_ReferenceRecords_ReferenceRecordId]
GO
ALTER TABLE [dbo].[ReferenceRecords]  WITH CHECK ADD  CONSTRAINT [FK_ReferenceRecords_AspNetUsers_PrimaryEntityId] FOREIGN KEY([PrimaryEntityId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ReferenceRecords] CHECK CONSTRAINT [FK_ReferenceRecords_AspNetUsers_PrimaryEntityId]
GO
ALTER TABLE [dbo].[RegulationPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_RegulationPropertyValues_Properties_PropertyId] FOREIGN KEY([PropertyId])
REFERENCES [dbo].[Properties] ([PropertyId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[RegulationPropertyValues] CHECK CONSTRAINT [FK_RegulationPropertyValues_Properties_PropertyId]
GO
ALTER TABLE [dbo].[RegulationPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_RegulationPropertyValues_Regulations_RegulationId] FOREIGN KEY([RegulationId])
REFERENCES [dbo].[Regulations] ([RegulationId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[RegulationPropertyValues] CHECK CONSTRAINT [FK_RegulationPropertyValues_Regulations_RegulationId]
GO
ALTER TABLE [dbo].[Reminders]  WITH CHECK ADD  CONSTRAINT [FK_Reminders_AspNetUsers_UserId] FOREIGN KEY([UserId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Reminders] CHECK CONSTRAINT [FK_Reminders_AspNetUsers_UserId]
GO
ALTER TABLE [dbo].[ReportRecordPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_ReportRecordPropertyValues_Properties_PropertyId] FOREIGN KEY([PropertyId])
REFERENCES [dbo].[Properties] ([PropertyId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ReportRecordPropertyValues] CHECK CONSTRAINT [FK_ReportRecordPropertyValues_Properties_PropertyId]
GO
ALTER TABLE [dbo].[ReportRecordPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_ReportRecordPropertyValues_ReportRecords_ReportRecordId] FOREIGN KEY([ReportRecordId])
REFERENCES [dbo].[ReportRecords] ([ReportRecordId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ReportRecordPropertyValues] CHECK CONSTRAINT [FK_ReportRecordPropertyValues_ReportRecords_ReportRecordId]
GO
ALTER TABLE [dbo].[ReportRecords]  WITH CHECK ADD  CONSTRAINT [FK_ReportRecords_AspNetUsers_PrimaryEntityId] FOREIGN KEY([PrimaryEntityId])
REFERENCES [dbo].[AspNetUsers] ([Id])
GO
ALTER TABLE [dbo].[ReportRecords] CHECK CONSTRAINT [FK_ReportRecords_AspNetUsers_PrimaryEntityId]
GO
ALTER TABLE [dbo].[ResumeRecordPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_ResumeRecordPropertyValues_Properties_PropertyId] FOREIGN KEY([PropertyId])
REFERENCES [dbo].[Properties] ([PropertyId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ResumeRecordPropertyValues] CHECK CONSTRAINT [FK_ResumeRecordPropertyValues_Properties_PropertyId]
GO
ALTER TABLE [dbo].[ResumeRecordPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_ResumeRecordPropertyValues_ResumeRecords_ResumeRecordId] FOREIGN KEY([ResumeRecordId])
REFERENCES [dbo].[ResumeRecords] ([ResumeRecordId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ResumeRecordPropertyValues] CHECK CONSTRAINT [FK_ResumeRecordPropertyValues_ResumeRecords_ResumeRecordId]
GO
ALTER TABLE [dbo].[ResumeRecords]  WITH CHECK ADD  CONSTRAINT [FK_ResumeRecords_AspNetUsers_PrimaryEntityId] FOREIGN KEY([PrimaryEntityId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ResumeRecords] CHECK CONSTRAINT [FK_ResumeRecords_AspNetUsers_PrimaryEntityId]
GO
ALTER TABLE [dbo].[ResumeSectionEntities]  WITH CHECK ADD  CONSTRAINT [FK_ResumeSectionEntities_ResumeSections_ResumeSectionId] FOREIGN KEY([ResumeSectionId])
REFERENCES [dbo].[ResumeSections] ([ResumeSectionId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ResumeSectionEntities] CHECK CONSTRAINT [FK_ResumeSectionEntities_ResumeSections_ResumeSectionId]
GO
ALTER TABLE [dbo].[ResumeSections]  WITH CHECK ADD  CONSTRAINT [FK_ResumeSections_EntityTypes_EntityTypeId] FOREIGN KEY([EntityTypeId])
REFERENCES [dbo].[EntityTypes] ([EntityTypeId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ResumeSections] CHECK CONSTRAINT [FK_ResumeSections_EntityTypes_EntityTypeId]
GO
ALTER TABLE [dbo].[ResumeSections]  WITH CHECK ADD  CONSTRAINT [FK_ResumeSections_ResumeRecords_ResumeRecordId] FOREIGN KEY([ResumeRecordId])
REFERENCES [dbo].[ResumeRecords] ([ResumeRecordId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ResumeSections] CHECK CONSTRAINT [FK_ResumeSections_ResumeRecords_ResumeRecordId]
GO
ALTER TABLE [dbo].[RolePromotionActions]  WITH CHECK ADD  CONSTRAINT [FK_RolePromotionActions_AspNetRoles_RoleId] FOREIGN KEY([RoleId])
REFERENCES [dbo].[AspNetRoles] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[RolePromotionActions] CHECK CONSTRAINT [FK_RolePromotionActions_AspNetRoles_RoleId]
GO
ALTER TABLE [dbo].[RolePromotionActions]  WITH CHECK ADD  CONSTRAINT [FK_RolePromotionActions_AspNetUsers_PrimaryEntityId] FOREIGN KEY([PrimaryEntityId])
REFERENCES [dbo].[AspNetUsers] ([Id])
GO
ALTER TABLE [dbo].[RolePromotionActions] CHECK CONSTRAINT [FK_RolePromotionActions_AspNetUsers_PrimaryEntityId]
GO
ALTER TABLE [dbo].[RolePromotionActions]  WITH CHECK ADD  CONSTRAINT [FK_RolePromotionActions_EmploymentRecords_EmploymentRecordId] FOREIGN KEY([EmploymentRecordId])
REFERENCES [dbo].[EmploymentRecords] ([EmploymentRecordId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[RolePromotionActions] CHECK CONSTRAINT [FK_RolePromotionActions_EmploymentRecords_EmploymentRecordId]
GO
ALTER TABLE [dbo].[RolePromotionActions]  WITH CHECK ADD  CONSTRAINT [FK_RolePromotionActions_Organizations_OrganizationId] FOREIGN KEY([OrganizationId])
REFERENCES [dbo].[Organizations] ([OrganizationId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[RolePromotionActions] CHECK CONSTRAINT [FK_RolePromotionActions_Organizations_OrganizationId]
GO
ALTER TABLE [dbo].[Rules]  WITH CHECK ADD  CONSTRAINT [FK_Rules_Regulations_RegulationId] FOREIGN KEY([RegulationId])
REFERENCES [dbo].[Regulations] ([RegulationId])
GO
ALTER TABLE [dbo].[Rules] CHECK CONSTRAINT [FK_Rules_Regulations_RegulationId]
GO
ALTER TABLE [dbo].[SeedProperties]  WITH CHECK ADD  CONSTRAINT [FK_SeedProperties_FormElements_FormElementId] FOREIGN KEY([FormElementId])
REFERENCES [dbo].[FormElements] ([FormElementId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[SeedProperties] CHECK CONSTRAINT [FK_SeedProperties_FormElements_FormElementId]
GO
ALTER TABLE [dbo].[SeedProperties]  WITH CHECK ADD  CONSTRAINT [FK_SeedProperties_SeedRecords_SeedRecordId] FOREIGN KEY([SeedRecordId])
REFERENCES [dbo].[SeedRecords] ([SeedRecordId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[SeedProperties] CHECK CONSTRAINT [FK_SeedProperties_SeedRecords_SeedRecordId]
GO
ALTER TABLE [dbo].[SeedRecords]  WITH CHECK ADD  CONSTRAINT [FK_SeedRecords_EntityTypes_EntityTypeId] FOREIGN KEY([EntityTypeId])
REFERENCES [dbo].[EntityTypes] ([EntityTypeId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[SeedRecords] CHECK CONSTRAINT [FK_SeedRecords_EntityTypes_EntityTypeId]
GO
ALTER TABLE [dbo].[TrainingRecordPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_TrainingRecordPropertyValues_Properties_PropertyId] FOREIGN KEY([PropertyId])
REFERENCES [dbo].[Properties] ([PropertyId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[TrainingRecordPropertyValues] CHECK CONSTRAINT [FK_TrainingRecordPropertyValues_Properties_PropertyId]
GO
ALTER TABLE [dbo].[TrainingRecordPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_TrainingRecordPropertyValues_TrainingRecords_TrainingRecordId] FOREIGN KEY([TrainingRecordId])
REFERENCES [dbo].[TrainingRecords] ([TrainingRecordId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[TrainingRecordPropertyValues] CHECK CONSTRAINT [FK_TrainingRecordPropertyValues_TrainingRecords_TrainingRecordId]
GO
ALTER TABLE [dbo].[TrainingRecords]  WITH CHECK ADD  CONSTRAINT [FK_TrainingRecords_AspNetUsers_PrimaryEntityId] FOREIGN KEY([PrimaryEntityId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[TrainingRecords] CHECK CONSTRAINT [FK_TrainingRecords_AspNetUsers_PrimaryEntityId]
GO
ALTER TABLE [dbo].[TrainingRecords]  WITH CHECK ADD  CONSTRAINT [FK_TrainingRecords_CourseRecords_CourseRecordId] FOREIGN KEY([CourseRecordId])
REFERENCES [dbo].[CourseRecords] ([CourseRecordId])
GO
ALTER TABLE [dbo].[TrainingRecords] CHECK CONSTRAINT [FK_TrainingRecords_CourseRecords_CourseRecordId]
GO
ALTER TABLE [dbo].[TrainingRecords]  WITH CHECK ADD  CONSTRAINT [FK_TrainingRecords_CourseSectionRecords_CourseSectionRecordId] FOREIGN KEY([CourseSectionRecordId])
REFERENCES [dbo].[CourseSectionRecords] ([CourseSectionRecordId])
GO
ALTER TABLE [dbo].[TrainingRecords] CHECK CONSTRAINT [FK_TrainingRecords_CourseSectionRecords_CourseSectionRecordId]
GO
ALTER TABLE [dbo].[TrainingRegulations]  WITH CHECK ADD  CONSTRAINT [FK_TrainingRegulations_CourseRecords_CourseRecordId] FOREIGN KEY([CourseRecordId])
REFERENCES [dbo].[CourseRecords] ([CourseRecordId])
GO
ALTER TABLE [dbo].[TrainingRegulations] CHECK CONSTRAINT [FK_TrainingRegulations_CourseRecords_CourseRecordId]
GO
ALTER TABLE [dbo].[TrainingRegulations]  WITH CHECK ADD  CONSTRAINT [FK_TrainingRegulations_Regulations_RegulationId] FOREIGN KEY([RegulationId])
REFERENCES [dbo].[Regulations] ([RegulationId])
GO
ALTER TABLE [dbo].[TrainingRegulations] CHECK CONSTRAINT [FK_TrainingRegulations_Regulations_RegulationId]
GO
ALTER TABLE [dbo].[TrainingRules]  WITH CHECK ADD  CONSTRAINT [FK_TrainingRules_CourseRecords_CourseRecordId] FOREIGN KEY([CourseRecordId])
REFERENCES [dbo].[CourseRecords] ([CourseRecordId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[TrainingRules] CHECK CONSTRAINT [FK_TrainingRules_CourseRecords_CourseRecordId]
GO
ALTER TABLE [dbo].[TrainingRules]  WITH CHECK ADD  CONSTRAINT [FK_TrainingRules_Rules_RuleId] FOREIGN KEY([RuleId])
REFERENCES [dbo].[Rules] ([RuleId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[TrainingRules] CHECK CONSTRAINT [FK_TrainingRules_Rules_RuleId]
GO
ALTER TABLE [dbo].[UserMessages]  WITH CHECK ADD  CONSTRAINT [FK_UserMessages_AspNetUsers_FromUserId] FOREIGN KEY([FromUserId])
REFERENCES [dbo].[AspNetUsers] ([Id])
GO
ALTER TABLE [dbo].[UserMessages] CHECK CONSTRAINT [FK_UserMessages_AspNetUsers_FromUserId]
GO
ALTER TABLE [dbo].[UserMessages]  WITH CHECK ADD  CONSTRAINT [FK_UserMessages_AspNetUsers_ToUserId] FOREIGN KEY([ToUserId])
REFERENCES [dbo].[AspNetUsers] ([Id])
GO
ALTER TABLE [dbo].[UserMessages] CHECK CONSTRAINT [FK_UserMessages_AspNetUsers_ToUserId]
GO
ALTER TABLE [dbo].[UserMessages]  WITH CHECK ADD  CONSTRAINT [FK_UserMessages_MessageContents_MessageContentId] FOREIGN KEY([MessageContentId])
REFERENCES [dbo].[MessageContents] ([MessageContentId])
GO
ALTER TABLE [dbo].[UserMessages] CHECK CONSTRAINT [FK_UserMessages_MessageContents_MessageContentId]
GO
ALTER TABLE [dbo].[UserOrganizationRoles]  WITH CHECK ADD  CONSTRAINT [FK_UserOrganizationRoles_AspNetRoles_RoleId] FOREIGN KEY([RoleId])
REFERENCES [dbo].[AspNetRoles] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[UserOrganizationRoles] CHECK CONSTRAINT [FK_UserOrganizationRoles_AspNetRoles_RoleId]
GO
ALTER TABLE [dbo].[UserOrganizationRoles]  WITH CHECK ADD  CONSTRAINT [FK_UserOrganizationRoles_AspNetUsers_UserId] FOREIGN KEY([UserId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[UserOrganizationRoles] CHECK CONSTRAINT [FK_UserOrganizationRoles_AspNetUsers_UserId]
GO
ALTER TABLE [dbo].[UserOrganizationRoles]  WITH CHECK ADD  CONSTRAINT [FK_UserOrganizationRoles_EmploymentRecords_EmploymentRecordId] FOREIGN KEY([EmploymentRecordId])
REFERENCES [dbo].[EmploymentRecords] ([EmploymentRecordId])
GO
ALTER TABLE [dbo].[UserOrganizationRoles] CHECK CONSTRAINT [FK_UserOrganizationRoles_EmploymentRecords_EmploymentRecordId]
GO
ALTER TABLE [dbo].[UserOrganizationRoles]  WITH CHECK ADD  CONSTRAINT [FK_UserOrganizationRoles_Organizations_OrganizationId] FOREIGN KEY([OrganizationId])
REFERENCES [dbo].[Organizations] ([OrganizationId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[UserOrganizationRoles] CHECK CONSTRAINT [FK_UserOrganizationRoles_Organizations_OrganizationId]
GO
ALTER TABLE [dbo].[UserPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_UserPropertyValues_AspNetUsers_UserId] FOREIGN KEY([UserId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[UserPropertyValues] CHECK CONSTRAINT [FK_UserPropertyValues_AspNetUsers_UserId]
GO
ALTER TABLE [dbo].[UserPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_UserPropertyValues_Properties_PropertyId] FOREIGN KEY([PropertyId])
REFERENCES [dbo].[Properties] ([PropertyId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[UserPropertyValues] CHECK CONSTRAINT [FK_UserPropertyValues_Properties_PropertyId]
GO
ALTER TABLE [dbo].[UserReferralPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_UserReferralPropertyValues_Properties_PropertyId] FOREIGN KEY([PropertyId])
REFERENCES [dbo].[Properties] ([PropertyId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[UserReferralPropertyValues] CHECK CONSTRAINT [FK_UserReferralPropertyValues_Properties_PropertyId]
GO
ALTER TABLE [dbo].[UserReferralPropertyValues]  WITH CHECK ADD  CONSTRAINT [FK_UserReferralPropertyValues_UserReferrals_UserReferralId] FOREIGN KEY([UserReferralId])
REFERENCES [dbo].[UserReferrals] ([UserReferralId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[UserReferralPropertyValues] CHECK CONSTRAINT [FK_UserReferralPropertyValues_UserReferrals_UserReferralId]
GO
ALTER TABLE [dbo].[UserReferrals]  WITH CHECK ADD  CONSTRAINT [FK_UserReferrals_AspNetUsers_PrimaryEntityId] FOREIGN KEY([PrimaryEntityId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[UserReferrals] CHECK CONSTRAINT [FK_UserReferrals_AspNetUsers_PrimaryEntityId]
GO
ALTER TABLE [dbo].[VerificationActions]  WITH CHECK ADD  CONSTRAINT [FK_VerificationActions_Organizations_AgencyOrganizationId] FOREIGN KEY([AgencyOrganizationId])
REFERENCES [dbo].[Organizations] ([OrganizationId])
GO
ALTER TABLE [dbo].[VerificationActions] CHECK CONSTRAINT [FK_VerificationActions_Organizations_AgencyOrganizationId]
GO
ALTER TABLE [dbo].[VerificationActions]  WITH CHECK ADD  CONSTRAINT [FK_VerificationActions_VerificationActions_ParentActionVerificationActionId] FOREIGN KEY([ParentActionVerificationActionId])
REFERENCES [dbo].[VerificationActions] ([VerificationActionId])
GO
ALTER TABLE [dbo].[VerificationActions] CHECK CONSTRAINT [FK_VerificationActions_VerificationActions_ParentActionVerificationActionId]
GO
ALTER TABLE [dbo].[VerificationActions]  WITH CHECK ADD  CONSTRAINT [FK_VerificationActions_Verifications_VerificationId] FOREIGN KEY([VerificationId])
REFERENCES [dbo].[Verifications] ([VerificationId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[VerificationActions] CHECK CONSTRAINT [FK_VerificationActions_Verifications_VerificationId]
GO
ALTER TABLE [dbo].[Verifications]  WITH CHECK ADD  CONSTRAINT [FK_Verifications_AspNetUsers_PrimaryEntityId] FOREIGN KEY([PrimaryEntityId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Verifications] CHECK CONSTRAINT [FK_Verifications_AspNetUsers_PrimaryEntityId]
GO
ALTER TABLE [dbo].[Verifications]  WITH CHECK ADD  CONSTRAINT [FK_Verifications_EntityTypes_EntityTypeId] FOREIGN KEY([EntityTypeId])
REFERENCES [dbo].[EntityTypes] ([EntityTypeId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Verifications] CHECK CONSTRAINT [FK_Verifications_EntityTypes_EntityTypeId]
GO
ALTER TABLE [dbo].[Verifications]  WITH CHECK ADD  CONSTRAINT [FK_Verifications_Organizations_AgencyOrganizationId] FOREIGN KEY([AgencyOrganizationId])
REFERENCES [dbo].[Organizations] ([OrganizationId])
GO
ALTER TABLE [dbo].[Verifications] CHECK CONSTRAINT [FK_Verifications_Organizations_AgencyOrganizationId]
GO
ALTER TABLE [HangFire].[JobParameter]  WITH CHECK ADD  CONSTRAINT [FK_HangFire_JobParameter_Job] FOREIGN KEY([JobId])
REFERENCES [HangFire].[Job] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [HangFire].[JobParameter] CHECK CONSTRAINT [FK_HangFire_JobParameter_Job]
GO
ALTER TABLE [HangFire].[State]  WITH CHECK ADD  CONSTRAINT [FK_HangFire_State_Job] FOREIGN KEY([JobId])
REFERENCES [HangFire].[Job] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [HangFire].[State] CHECK CONSTRAINT [FK_HangFire_State_Job]
GO
/****** Object:  StoredProcedure [dbo].[ApplicationLogInsert]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE   PROCEDURE [dbo].[ApplicationLogInsert]
    @machineName NVARCHAR(200),
    @logged DATETIME,
    @level VARCHAR(5),
    @message NVARCHAR(MAX),
    @logger NVARCHAR(300),
    @properties NVARCHAR(MAX),
    @callsite NVARCHAR(300),
    @exception NVARCHAR(MAX),
	@logGuid NVARCHAR(450)
AS
BEGIN
    INSERT INTO [dbo].[ApplicationLog]
    (
        [MachineName],
        [Logged],
        [Level],
        [Message],
        [Logger],
        [Properties],
        [Callsite],
        [Exception],
		[ApplicationLogGuid]
    )
    VALUES
    (@machineName, @logged, @level, @message, @logger, @properties, @callsite, @exception, @logGuid);
END;

GO
/****** Object:  StoredProcedure [dbo].[CreateUpdateAuditObjects]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROC [dbo].[CreateUpdateAuditObjects] 
AS
SET NOCOUNT ON;

SELECT *
INTO #tables
FROM sys.objects
WHERE type = 'U'
AND name NOT IN ('__EFMigrationsHistory', 'ApplicationLog', 'LoginHistories' )
AND SCHEMA_NAME(schema_id) = 'dbo'

DECLARE @workingID AS INT
DECLARE @workingName AS sysname

IF NOT EXISTS( SELECT * FROM sys.schemas WHERE name = 'audit')
BEGIN
	EXEC ('CREATE SCHEMA [audit] AUTHORIZATION [dbo]') 
END

WHILE (SELECT COUNT(*) FROM #tables) > 0
BEGIN
	SET @workingID = (SELECT MIN(object_id) FROM #tables)
	SET @workingName = (SELECT name FROM #tables WHERE object_id = @workingID)

	EXEC dbo.GenerateTriggers @Schemaname = 'dbo',                   -- sysname
								@Tablename = @workingName,                    -- sysname
								@GenerateScriptOnly = 0,           -- bit
								@ForceDropAuditTable = 0,          -- bit
								@IgnoreExistingColumnMismatch = 0, -- bit
								@DontAuditforUsers = N'',             -- nvarchar(4000)
								@DontAuditforColumns = N'LastChangeDateTime'            -- nvarchar(4000)
	
	DELETE FROM #tables WHERE object_id = @workingID
END

DROP TABLE #tables

GO
/****** Object:  StoredProcedure [dbo].[GenerateTriggers]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE   PROC [dbo].[GenerateTriggers]
    @Schemaname sysname = 'dbo',
    @Tablename sysname,
    @GenerateScriptOnly BIT = 1,
    @ForceDropAuditTable BIT = 0,
    @IgnoreExistingColumnMismatch BIT = 0,
    @DontAuditforUsers NVARCHAR(4000) = '',
    @DontAuditforColumns NVARCHAR(4000) = ''
AS
SET NOCOUNT ON;

/*   
Parameters   
@Schemaname            - SchemaName to which the table belongs to. Default value 'dbo'.   
@Tablename            - TableName for which the procs needs to be generated.   
@GenerateScriptOnly - When passed 1 , this will generate the scripts alone..   
                      When passed 0 , this will create the audit tables and triggers in the current database.   
                      Default value is 1   
@ForceDropAuditTable - When passed 1 , will drop the audit table and recreate 
                       When passed 0 , will generate the alter scripts 
                       Default value is 0 
@IgnoreExistingColumnMismatch - When passed 1 , will not stop with the error on the mismatch of existing column and will create the trigger. 
                                When passed 0 , will stop with the error on the mismatch of existing column. 
                                Default value is 0 
@DontAuditforUsers - Pass the UserName as comma seperated for whom the audit is not required.
					 Default value is '' which will do audit for all the users.

@DontAuditforColumns - Pass the ColumnNames as comma seperated for which the audit is not required.
      Default value is '' which will do audit for all the users.
*/

DECLARE @SQL VARCHAR(MAX);
DECLARE @SQLTrigger VARCHAR(MAX);
DECLARE @ErrMsg VARCHAR(MAX);

DECLARE @AuditSchemaName sysname = 'audit';
DECLARE @AuditTableName sysname;
DECLARE @QuotedSchemaName sysname;
DECLARE @QuotedTableName sysname;
DECLARE @QuotedAuditTableName sysname;
DECLARE @QuotedAuditSchemaName sysname;
DECLARE @InsertTriggerName sysname;
DECLARE @UpdateTriggerName sysname;
DECLARE @DeleteTriggerName sysname;
DECLARE @QuotedInsertTriggerName sysname;
DECLARE @QuotedUpdateTriggerName sysname;
DECLARE @QuotedDeleteTriggerName sysname;
DECLARE @DontAuditforUsersTmp NVARCHAR(4000);

SELECT @AuditTableName = @Tablename; -- + '_Audit';
SELECT @QuotedSchemaName = QUOTENAME(@Schemaname);
SELECT @QuotedTableName = QUOTENAME(@Tablename);
SELECT @QuotedAuditTableName = QUOTENAME(@AuditTableName);
SELECT @QuotedAuditSchemaName = QUOTENAME(@AuditSchemaName);
SELECT @InsertTriggerName = @Tablename + '_Insert';
SELECT @UpdateTriggerName = @Tablename + '_Update';
SELECT @DeleteTriggerName = @Tablename + '_Delete';
SELECT @QuotedInsertTriggerName = QUOTENAME(@InsertTriggerName);
SELECT @QuotedUpdateTriggerName = QUOTENAME(@UpdateTriggerName);
SELECT @QuotedDeleteTriggerName = QUOTENAME(@DeleteTriggerName);

IF LTRIM(RTRIM(@DontAuditforUsers)) <> ''
BEGIN

    IF RIGHT(@DontAuditforUsers, 1) = ','
    BEGIN
        SELECT @DontAuditforUsersTmp = LEFT(@DontAuditforUsers, LEN(@DontAuditforUsers) - 1);
    END;
    ELSE
    BEGIN
        SELECT @DontAuditforUsersTmp = @DontAuditforUsers;
    END;

    SELECT @DontAuditforUsersTmp = REPLACE(@DontAuditforUsersTmp, ',', ''',''');

END;


SELECT @DontAuditforColumns = ',' + UPPER(@DontAuditforColumns) + ',';

IF NOT EXISTS
(
    SELECT 1
    FROM sys.objects
    WHERE name = @Tablename
          AND schema_id = SCHEMA_ID(@Schemaname)
          AND type = 'U'
)
BEGIN
    SELECT @ErrMsg = @QuotedSchemaName + '.' + @QuotedTableName + ' Table Not Found ';
    RAISERROR(@ErrMsg, 16, 1);
    RETURN;
END;


----------------------------------------------------------------------------------------------------------------------   
-- Audit Create OR Alter table    
----------------------------------------------------------------------------------------------------------------------   

DECLARE @ColList VARCHAR(MAX);
DECLARE @InsertColList VARCHAR(MAX);
DECLARE @UpdateCheck VARCHAR(MAX);

DECLARE @NewAddedCols TABLE
(
    ColumnName sysname,
    DataType sysname,
    CharLength INT,
    Collation sysname NULL,
    ChangeType VARCHAR(20) NULL,
    MainTableColumnName sysname NULL,
    MainTableDataType sysname NULL,
    MainTableCharLength INT NULL,
    MainTableCollation sysname NULL,
    AuditTableColumnName sysname NULL,
    AuditTableDataType sysname NULL,
    AuditTableCharLength INT NULL,
    AuditTableCollation sysname NULL
);


SELECT @ColList = '';
SELECT @UpdateCheck = ' ';
SELECT @SQL = '';
SELECT @InsertColList = '';


SELECT @ColList = @ColList + CASE SC.is_identity
                                 WHEN 1 THEN
                                     'CONVERT(' + ST.name + ',' + QUOTENAME(SC.name) + ') as ' + QUOTENAME(SC.name)
                                 ELSE
                                     QUOTENAME(SC.name)
                             END + ',',
       @InsertColList = @InsertColList + QUOTENAME(SC.name) + ',',
       @UpdateCheck
           = @UpdateCheck
             + CASE
                   WHEN CHARINDEX(',' + UPPER(SC.name) + ',', @DontAuditforColumns) = 0 THEN
                       'CASE WHEN UPDATE(' + QUOTENAME(SC.name) + ') THEN ''' + QUOTENAME(SC.name)
                       + '-'' ELSE '''' END + ' + CHAR(10)
                   ELSE
                       ''
               END
FROM sys.columns SC
    JOIN sys.objects SO
        ON SC.object_id = SO.object_id
    JOIN sys.schemas SCH
        ON SCH.schema_id = SO.schema_id
    JOIN sys.types ST
        ON ST.user_type_id = SC.user_type_id
           AND ST.system_type_id = SC.system_type_id
WHERE SCH.name = @Schemaname
      AND SO.name = @Tablename
      AND UPPER(ST.name) <> UPPER('timestamp');

SELECT @ColList = SUBSTRING(@ColList, 1, LEN(@ColList) - 1);
SELECT @UpdateCheck = SUBSTRING(@UpdateCheck, 1, LEN(@UpdateCheck) - 3);
SELECT @InsertColList = SUBSTRING(@InsertColList, 1, LEN(@InsertColList) - 1);

SELECT @InsertColList = @InsertColList + ',AuditDMLAction,AuditUser,AuditDateTime';

IF EXISTS
(
    SELECT 1
    FROM sys.objects
    WHERE name = @AuditTableName
          AND schema_id = SCHEMA_ID(@AuditSchemaName)
          AND type = 'U'
)
   AND @ForceDropAuditTable = 0
BEGIN

    ----------------------------------------------------------------------------------------------------------------------   
    -- Get the comparision metadata for Main and Audit Tables 
    ----------------------------------------------------------------------------------------------------------------------   

    INSERT INTO @NewAddedCols
    (
        ColumnName,
        DataType,
        CharLength,
        Collation,
        ChangeType,
        MainTableColumnName,
        MainTableDataType,
        MainTableCharLength,
        MainTableCollation,
        AuditTableColumnName,
        AuditTableDataType,
        AuditTableCharLength,
        AuditTableCollation
    )
    SELECT ISNULL(MainTable.ColumnName, AuditTable.ColumnName),
           ISNULL(MainTable.DataType, AuditTable.DataType),
           ISNULL(MainTable.CharLength, AuditTable.CharLength),
           ISNULL(MainTable.Collation, AuditTable.Collation),
           CASE
               WHEN MainTable.ColumnName IS NULL THEN
                   'Deleted'
               WHEN AuditTable.ColumnName IS NULL THEN
                   'Added'
               ELSE
                   NULL
           END,
           MainTable.ColumnName,
           MainTable.DataType,
           MainTable.CharLength,
           MainTable.Collation,
           AuditTable.ColumnName,
           AuditTable.DataType,
           AuditTable.CharLength,
           AuditTable.Collation
    FROM
    (
        SELECT SC.name AS ColumnName,
               ST.name AS DataType,
               SC.is_identity AS isIdentity,
               SC.max_length AS CharLength,
               SC.collation_name AS Collation
        FROM sys.columns SC
            JOIN sys.objects SO
                ON SC.object_id = SO.object_id
            JOIN sys.schemas SCH
                ON SCH.schema_id = SO.schema_id
            JOIN sys.types ST
                ON ST.user_type_id = SC.user_type_id
                   AND ST.system_type_id = SC.system_type_id
        WHERE SCH.name = @Schemaname
              AND SO.name = @Tablename
              AND UPPER(ST.name) <> UPPER('timestamp')
    ) MainTable
        FULL OUTER JOIN
        (
            SELECT SC.name AS ColumnName,
                   ST.name AS DataType,
                   SC.is_identity AS isIdentity,
                   SC.max_length AS CharLength,
                   SC.collation_name AS Collation
            FROM sys.columns SC
                JOIN sys.objects SO
                    ON SC.object_id = SO.object_id
                JOIN sys.schemas SCH
                    ON SCH.schema_id = SO.schema_id
                JOIN sys.types ST
                    ON ST.user_type_id = SC.user_type_id
                       AND ST.system_type_id = SC.system_type_id
            WHERE SCH.name = @AuditSchemaName
                  AND SO.name = @AuditTableName
                  AND UPPER(ST.name) <> UPPER('timestamp')
                  AND SC.name NOT IN ( 'AuditDMLAction', 'AuditUser', 'AuditDateTime' )
        ) AuditTable
            ON MainTable.ColumnName = AuditTable.ColumnName;

    ----------------------------------------------------------------------------------------------------------------------   
    -- Find data type changes between table 
    ----------------------------------------------------------------------------------------------------------------------   

    IF EXISTS
    (
        SELECT *
        FROM @NewAddedCols NC
        WHERE NC.MainTableColumnName = NC.AuditTableColumnName
              AND
              (
                  NC.MainTableDataType <> NC.AuditTableDataType
                  OR NC.MainTableCharLength > NC.AuditTableCharLength
                  OR NC.MainTableCollation <> NC.AuditTableCollation
              )
    )
    BEGIN
        SELECT CONVERT(   VARCHAR(50),
                          CASE
                              WHEN NC.MainTableDataType <> NC.AuditTableDataType THEN
                                  'DataType Mismatch'
                              WHEN NC.MainTableCharLength > NC.AuditTableCharLength THEN
                                  'Length in maintable is greater than Audit Table'
                              WHEN NC.MainTableCollation <> NC.AuditTableCollation THEN
                                  'Collation Difference'
                          END
                      ) AS Mismatch,
               NC.MainTableColumnName,
               NC.MainTableDataType,
               NC.MainTableCharLength,
               NC.MainTableCollation,
               NC.AuditTableColumnName,
               NC.AuditTableDataType,
               NC.AuditTableCharLength,
               NC.AuditTableCollation
        FROM @NewAddedCols NC
        WHERE NC.MainTableColumnName = NC.AuditTableColumnName
              AND
              (
                  NC.MainTableDataType <> NC.AuditTableDataType
                  OR NC.MainTableCharLength > NC.AuditTableCharLength
                  OR NC.MainTableCollation <> NC.AuditTableCollation
              );

        RAISERROR(
                     'There are differences in Datatype or Lesser Length or Collation difference between the Main table and Audit Table. Please refer the output',
                     16,
                     1
                 );
        IF @IgnoreExistingColumnMismatch = 0
        BEGIN
            RETURN;
        END;
    END;

    ----------------------------------------------------------------------------------------------------------------------   
    -- Find the new and deleted columns  
    ----------------------------------------------------------------------------------------------------------------------   

    IF EXISTS (SELECT * FROM @NewAddedCols WHERE ChangeType IS NOT NULL)
    BEGIN

        SELECT @SQL
            = @SQL + 'ALTER TABLE ' + @AuditSchemaName + '.' + @QuotedAuditTableName
              + CASE
                    WHEN NC.ChangeType = 'Added' THEN
                        ' ADD ' + QUOTENAME(NC.ColumnName) + ' ' + NC.DataType + ' '
                        + CASE
                              WHEN NC.DataType IN ( 'char', 'varchar', 'nchar', 'nvarchar' )
                                   AND NC.CharLength = -1 THEN
                                  '(max) COLLATE ' + NC.Collation + ' NULL '
                              WHEN NC.DataType IN ( 'char', 'varchar' ) THEN
                                  '(' + CONVERT(VARCHAR(5), NC.CharLength) + ') COLLATE ' + NC.Collation + ' NULL '
                              WHEN NC.DataType IN ( 'nchar', 'nvarchar' ) THEN
                                  '(' + CONVERT(VARCHAR(5), NC.CharLength / 2) + ') COLLATE ' + NC.Collation + ' NULL '
                              ELSE
                                  ''
                          END
                    WHEN NC.ChangeType = 'Deleted' THEN
                        ' DROP COLUMN ' + QUOTENAME(NC.ColumnName)
                END + CHAR(10)
        FROM @NewAddedCols NC
        WHERE NC.ChangeType IS NOT NULL;
    END;


END;
ELSE
BEGIN

    SELECT @SQL
        = '  IF EXISTS (SELECT 1    
						FROM sys.objects    
						WHERE Name=''' + @AuditTableName + '''   
							AND Schema_id=Schema_id(''' + @AuditSchemaName
          + '''			)   
							AND Type = ''U'')   
				DROP TABLE ' + @QuotedAuditSchemaName + '.' + @QuotedAuditTableName + '
  
                SELECT ' + REPLACE(REPLACE(@ColList, '[', 'B.['), 'as B.[', 'as [')
          + '     
                        ,AuditDMLAction=CONVERT(VARCHAR(10),'''')     
                        ,AuditUser =CONVERT(VARCHAR(50), CONTEXT_INFO())   
                        ,AuditDateTime=CONVERT(DATETIME,''01-JAN-1900'')
                        Into ' + @QuotedAuditSchemaName + '.' + @QuotedAuditTableName
          + '   
                    FROM ' + @QuotedSchemaName + '.' + @QuotedTableName + '    
					LEFT JOIN ' + @QuotedSchemaName + '.' + @QuotedTableName
          + ' B ON 1=2
                    WHERE 1=2 ';
END;



IF @GenerateScriptOnly = 1
BEGIN
    PRINT REPLICATE('-', 200);
    PRINT '--Create \ Alter Script Audit table for ' + @QuotedSchemaName + '.' + @QuotedTableName;
    PRINT REPLICATE('-', 200);
    PRINT @SQL;
    IF LTRIM(RTRIM(@SQL)) <> ''
    BEGIN
        PRINT 'GO';
    END;
    ELSE
    BEGIN
        PRINT '-- No changes in table structure';
    END;
END;
ELSE
BEGIN
    IF RTRIM(LTRIM(@SQL)) = ''
    BEGIN
        PRINT 'No Table Changes Found';
    END;
    ELSE
    BEGIN
        PRINT 'Creating \ Altered Audit table for ' + @QuotedSchemaName + '.' + @QuotedTableName;
        EXEC (@SQL);
        PRINT 'Audit table ' + @QuotedAuditSchemaName + '.' + @QuotedAuditTableName + ' Created \ Altered succesfully';
    END;
END;


----------------------------------------------------------------------------------------------------------------------   
-- Create Delete Trigger   
----------------------------------------------------------------------------------------------------------------------   


SELECT @SQL = '   
   
IF EXISTS (SELECT 1    
             FROM sys.objects    
            WHERE Name=''' + @Tablename + '_Delete' + '''   
              AND Schema_id=Schema_id(''' + @Schemaname + ''')   
              AND Type = ''TR'')   
DROP TRIGGER ' + @QuotedSchemaName + '.' + +@QuotedDeleteTriggerName + '   
';

SELECT @SQLTrigger = '   
CREATE TRIGGER ' + @QuotedSchemaName + '.' + @QuotedDeleteTriggerName + '   
ON ' + @QuotedSchemaName + '.' + @QuotedTableName + '   
FOR DELETE   
AS   ';

IF LTRIM(RTRIM(@DontAuditforUsersTmp)) <> ''
BEGIN

    SELECT @SQLTrigger = @SQLTrigger + CHAR(10) + ' IF SUSER_NAME() NOT IN (''' + @DontAuditforUsersTmp + ''')';
    SELECT @SQLTrigger = @SQLTrigger + CHAR(10) + ' BEGIN';

END;



SELECT @SQLTrigger
    = @SQLTrigger + CHAR(10) + '  INSERT INTO ' + @QuotedAuditSchemaName + '.' + @QuotedAuditTableName + CHAR(10) + '('
      + @InsertColList + ')' + CHAR(10) + 'SELECT ' + @ColList
      + ',''Delete'',CONVERT(VARCHAR(50), CONTEXT_INFO()),getdate()  FROM DELETED';

IF LTRIM(RTRIM(@DontAuditforUsersTmp)) <> ''
BEGIN

    SELECT @SQLTrigger = @SQLTrigger + CHAR(10) + ' END';

END;


IF @GenerateScriptOnly = 1
BEGIN
    PRINT REPLICATE('-', 200);
    PRINT '--Create Script Delete Trigger for ' + @QuotedSchemaName + '.' + @QuotedTableName;
    PRINT REPLICATE('-', 200);
    PRINT @SQL;
    PRINT 'GO';
    PRINT @SQLTrigger;
    PRINT 'GO';
END;
ELSE
BEGIN
    PRINT 'Creating Delete Trigger ' + @QuotedDeleteTriggerName + '  for ' + @QuotedSchemaName + '.' + @QuotedTableName;
    EXEC (@SQL);
    EXEC (@SQLTrigger);
    PRINT 'Trigger ' + @QuotedSchemaName + '.' + @QuotedDeleteTriggerName + ' Created succesfully';
END;

----------------------------------------------------------------------------------------------------------------------   
-- Create Update Trigger   
----------------------------------------------------------------------------------------------------------------------   


SELECT @SQL = '   
   
IF EXISTS (SELECT 1    
             FROM sys.objects    
            WHERE Name=''' + @Tablename + '_Update' + '''   
              AND Schema_id=Schema_id(''' + @Schemaname + ''')   
              AND Type = ''TR'')   
DROP TRIGGER ' + @QuotedSchemaName + '.' + @QuotedUpdateTriggerName + '   
';

SELECT @SQLTrigger = '   
CREATE TRIGGER ' + @QuotedSchemaName + '.' + @QuotedUpdateTriggerName + '     
ON ' + @QuotedSchemaName + '.' + @QuotedTableName + '   
FOR UPDATE   
AS ';

IF LTRIM(RTRIM(@DontAuditforUsersTmp)) <> ''
BEGIN

    SELECT @SQLTrigger = @SQLTrigger + CHAR(10) + ' IF SUSER_NAME() NOT IN (''' + @DontAuditforUsersTmp + ''')';
    SELECT @SQLTrigger = @SQLTrigger + CHAR(10) + ' BEGIN';

END;



SELECT @SQLTrigger
    = @SQLTrigger + CHAR(10) + '  

	DECLARE @UpdatedCols varchar(max)

   SELECT @UpdatedCols = ' + @UpdateCheck + '
   
   IF LTRIM(RTRIM(@UpdatedCols)) <> ''''
   BEGIN '
      +
    /*  INSERT INTO ' + @QuotedSchemaName + '.' + @QuotedAuditTableName + CHAR(10) + '(' + @InsertColList + ')'
      + CHAR(10) + 'SELECT ' + @ColList
      + ',''New'',''Update'',SUSER_SNAME(),getdate()  FROM INSERTED   */
    '  INSERT INTO ' + @QuotedAuditSchemaName + '.' + @QuotedAuditTableName + CHAR(10) + '(' + @InsertColList + ')'
      + CHAR(10) + 'SELECT ' + @ColList
      + ',''Update'', CONVERT(VARCHAR(50), CONTEXT_INFO()), getdate()  FROM DELETED 
   END';

IF LTRIM(RTRIM(@DontAuditforUsersTmp)) <> ''
BEGIN

    SELECT @SQLTrigger = @SQLTrigger + CHAR(10) + ' END';

END;



IF @GenerateScriptOnly = 1
BEGIN
    PRINT REPLICATE('-', 200);
    PRINT '--Create Script Update Trigger for ' + @QuotedSchemaName + '.' + @QuotedTableName;
    PRINT REPLICATE('-', 200);
    PRINT @SQL;
    PRINT 'GO';
    PRINT @SQLTrigger;
    PRINT 'GO';
END;
ELSE
BEGIN
    PRINT 'Creating Delete Trigger ' + @QuotedUpdateTriggerName + '  for ' + @QuotedSchemaName + '.' + @QuotedTableName;
    EXEC (@SQL);
    EXEC (@SQLTrigger);
    PRINT 'Trigger ' + @QuotedSchemaName + '.' + @QuotedUpdateTriggerName + '  Created succesfully';
END;

SET NOCOUNT OFF;

GO
/****** Object:  StoredProcedure [dbo].[reload_agencies]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE       PROCEDURE[dbo].[reload_agencies] AS
									 BEGIN

							DECLARE
								@OrgId nvarchar(450),
		                        @TASID nvarchar(450),
								@Provider_Name nvarchar(450),
		                        @County_Name nvarchar(450),
								@ProvTypeCode nvarchar(1),
								@Provider_Type nvarchar(450),
								@Regulatory_Agency nvarchar(450),
								@RegStatCode nvarchar(1),
								@Regulatory_Status nvarchar(450),
								@Regu_Individual nvarchar(450),
								@Regu_Individual_Phone nvarchar(450),
								@Regu_Individual_Email nvarchar(450),
		                        @Location_Street_1 nvarchar(450), 
		                        @Location_City nvarchar(450), 
		                        @Location_State nvarchar(450), 
		                        @Location_Zip nvarchar(450),
								@RegionCode nvarchar(450),
								@Region nvarchar(450),

								@CurName nvarchar(450),
								@CurOrgId nvarchar(450),
								@TASIDID nvarchar(450),
		                        @CurProviderName nvarchar(450),
								@CurCounty nvarchar(450),
								@CurProviderType nvarchar(450),
								@CurRegulatoryAgency nvarchar(450),
								@CurRegulatoryStatus nvarchar(450),
								@CurReguIndividual nvarchar(450),
								@CurReguIndividualPhone nvarchar(450),
								@CurReguIndividualEmail nvarchar(450),
		                        @CurLocStreet1 nvarchar(450),
		                        @CurCity nvarchar(450),
		                        @CurState nvarchar(450),
		                        @CurZip nvarchar(450),
								@CurRegion nvarchar(450),
                                @CurSearchDisplayName nvarchar(450),

		                        @OPV nvarchar(450),
		                        @IsDisabled bit,
								@IsAgencyId int,
								@OrgCodeId int,
								@CountyNameId int,
								@LocationStreet1Id int,
								@LocationCityId int,
								@LocationStateId int,
								@LocationZipId int,
								@RegionId int,
								@RegulatoryAgencyId int,
								@ReguIndividualId int,
								@ReguIndividualPhoneId int,
								@ReguIndividualEmailId int,
								@ProviderTypeId int,
								@AgencyStatusId int,
								@AdminUserId nvarchar(450),

                                @NameCount int,
								@NameCityCount int,
                                @NameCityStatusCount int,
								@SearchDisplayName nvarchar(450),
                                @SearchDisplayNameId int,

								@SearchDisplayPV int,
								@ProviderTypePV int,
								@RegulatoryAgencyPV int,
								@ReguIndividualPV int,
								@ReguIndividualPhonePV int,
								@ReguIndividualEmailPV int,
                                @RegulatoryStatusPV int,
								@SetDisabled bit;

						-- verify that temp_provider exists and is populated (how many rows)
						if (SELECT count(*) from temp_provider) < 1500
							RETURN -1;

						SELECT @IsAgencyId = (
							SELECT PropertyId
							FROM Properties
							WHERE Name = 'IsAgency'
						);
						IF @IsAgencyId IS NULL
							RETURN - 1;

						SELECT @OrgCodeId = (
							SELECT PropertyId
							FROM Properties
							WHERE Name = 'Organization Code'
	                    );
						IF @OrgCodeId IS NULL
							RETURN - 1;

						SELECT @CountyNameId = (
							SELECT PropertyId
							FROM Properties
							WHERE Name = 'County'
	                    );
						IF @CountyNameId IS NULL
							RETURN - 1;

						SELECT @LocationStreet1Id = (
							SELECT PropertyId
							FROM Properties
							WHERE Name = 'Address Line 1'
	                    );
						IF @LocationStreet1Id IS NULL
							RETURN - 1;

						SELECT @LocationCityId = (
							SELECT PropertyId
							FROM Properties
							WHERE Name = 'City'
	                    );
						IF @LocationCityId IS NULL
							RETURN - 1;

						SELECT @LocationStateId = (
							SELECT PropertyId
							FROM Properties
							WHERE Name = 'State'
	                    );
						IF @LocationStateId IS NULL
							RETURN - 1;

						SELECT @LocationZipId = (
							SELECT PropertyId
							FROM Properties
							WHERE Name = 'Zip Code'
	                    );
						IF @LocationZipId IS NULL
							RETURN - 1;

						SELECT @RegionId = (
							SELECT PropertyId
							FROM Properties
							WHERE Name = 'Region'
	                    );
						IF @RegionId IS NULL
							RETURN - 1;

						SELECT @ProviderTypeId = (
							SELECT PropertyId
							FROM Properties
							WHERE Name = 'Provider Type'
	                    );
						IF @ProviderTypeId IS NULL
							RETURN - 1;

						SELECT @RegulatoryAgencyId = (
							SELECT PropertyId
							FROM Properties
							WHERE Name = 'Regulatory Agency'
	                    );
						IF @RegulatoryAgencyId IS NULL
							RETURN - 1;

						SELECT @ReguIndividualId = (
							SELECT PropertyId
							FROM Properties
							WHERE Name = 'Child Care Consultant'
	                    );
						IF @ReguIndividualId IS NULL
							RETURN - 1;

						SELECT @ReguIndividualPhoneId = (
							SELECT PropertyId
							FROM Properties
							WHERE Name = 'Child Care Consultant Phone'
	                    );
						IF @ReguIndividualPhoneId IS NULL
							RETURN - 1;

						SELECT @ReguIndividualEmailId = (
							SELECT PropertyId
							FROM Properties
							WHERE Name = 'Child Care Consultant Email'
	                    );
						IF @ReguIndividualEmailId IS NULL
							RETURN - 1;

						SELECT @AgencyStatusId = (
							SELECT PropertyId
							FROM Properties
							WHERE Name = 'Agency Status'
	                    );
						IF @AgencyStatusId IS NULL
							RETURN - 1;

						SELECT @AdminUserId = (
							SELECT Id
							FROM AspNetUsers
							WHERE UserName = 'wfradmin@jhuideals.org'
	                    );
						IF @AdminUserId IS NULL
							RETURN - 1;

						SELECT @SearchDisplayNameId = (
							SELECT PropertyId
							FROM Properties
							WHERE Name = 'Search Display Name'
	                    );
						IF @SearchDisplayNameId IS NULL
							RETURN - 1;

						UPDATE Organizations
							SET Disabled = 1
							WHERE OrganizationId IN
							(SELECT a.OrganizationId
								FROM Organizations a
								JOIN OrganizationPropertyValues b ON a.OrganizationId = b.OrganizationId
								JOIN OrganizationPropertyValues c ON a.OrganizationId = c.OrganizationId
								WHERE b.PropertyId = @OrgCodeId AND c.PropertyId = @IsAgencyId
								AND b.ValueText NOT IN
								(SELECT TASID
									FROM temp_provider
									WHERE Provider_Close_date is null
		                        )
							);


						DECLARE agency_cursor CURSOR FAST_FORWARD FOR
							SELECT
								TASID, Provider_Name, COUNTY_NAME, Provider_Type,
								Licensing_Angency, LEGLICSTAT, Licensing_Consultant_Name,
								Licensing_Consultant_Phone, Licensing_Consultant_Email,
		                        PADDR, PCITY, PSTATE, PZIP, Region_Name
							FROM temp_provider;
							OPEN agency_cursor
							FETCH NEXT FROM agency_cursor
							INTO
								@TASID, @Provider_Name, @County_Name, @ProvTypeCode,
								@Regulatory_Agency, @RegStatCode, @Regu_Individual,
								@Regu_Individual_Phone, @Regu_Individual_Email,
								@Location_Street_1, @Location_City, @Location_State, 
								@Location_Zip, @RegionCode

							WHILE @@FETCH_STATUS = 0

							BEGIN
								
								IF @Regulatory_Status = 'X'
									SELECT @SetDisabled = 1;
								ELSE
									SELECT @SetDisabled = 0;

								SELECT @Provider_Type = 
									CASE 
										WHEN @ProvTypeCode = 'C' THEN 'Center' 
										WHEN @ProvTypeCode = 'F' THEN 'Family'
										WHEN @ProvTypeCode = 'G' THEN 'Group'
										ELSE ''
									END;

								SELECT @Regulatory_Status = 
									CASE 
										WHEN @RegStatCode = 'L' THEN 'Licensed' 
										WHEN @RegStatCode = 'E' THEN 'Exempt'
										WHEN @RegStatCode = 'X' THEN 'Exempted'
										ELSE ''
									END;

								SELECT @Region = 
									CASE 
										WHEN SUBSTRING(@RegionCode,1,4) = '2001' THEN 'Huntsville' 
										WHEN SUBSTRING(@RegionCode,1,4) = '2002' THEN 'Mobile' 
										WHEN SUBSTRING(@RegionCode,1,4) = '2003' THEN 'Birmingham' 
										WHEN SUBSTRING(@RegionCode,1,4) = '2004' THEN 'Montgomery' 
										WHEN SUBSTRING(@RegionCode,1,4) = '2005' THEN 'Opelika' 
										WHEN SUBSTRING(@RegionCode,1,4) = '2008' THEN 'Tuscaloosa' 
										WHEN SUBSTRING(@RegionCode,1,4) = '2010' THEN 'Fort Payne' 
										WHEN SUBSTRING(@RegionCode,1,4) = '2011' THEN 'Talladega' 
										WHEN SUBSTRING(@RegionCode,1,4) = '2012' THEN 'Dothan' 
										ELSE ''
									END;

								SELECT @NameCount = (SELECT count(*) from temp_provider
                                                    WHERE LOWER(Provider_Name) = LOWER(@Provider_Name));

								SELECT @NameCityCount = (SELECT count(*) from temp_provider
                                                    WHERE LOWER(Provider_Name) = LOWER(@Provider_Name)
													AND LOWER(PCITY) = LOWER(@Location_City));


								IF(@NameCount = 1)
									SELECT @SearchDisplayName = @Provider_Name;
								ELSE IF (@NameCityCount = 1)
									SELECT @SearchDisplayName = @Provider_Name + ' (' + @Location_City + ')';
								ELSE
									SELECT @SearchDisplayName = @Provider_Name + ' (' + @Location_Street_1 + ', ' + @Location_City + ')';

								SELECT @OrgId = (
									SELECT OrganizationId
									FROM OrganizationPropertyValues
									WHERE PropertyId = @OrgCodeId
									AND ValueText = @TASID
		                        );
								IF @OrgId IS NULL 
								BEGIN
									SELECT @OrgId = NEWID();
									INSERT INTO Organizations
									(
										OrganizationId, OrganizationName, Disabled,
										CreationDateTime, LastChangeDateTime,
										CreationByUserId, LastChangeByUserId
									)
									VALUES
									(
										@OrgId, @Provider_Name, @SetDisabled,
										CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,
										@AdminUserId, @AdminUserId
									);
									INSERT INTO OrganizationPropertyValues
									(
										CreationDateTime, LastChangeDateTime,
										CreationByUserId, LastChangeByUserId,
										ValueInt, PropertyId, OrganizationId
									)
									VALUES
									(
										CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,
										@AdminUserId, @AdminUserId,
										(SELECT PropertyChoiceId
											FROM PropertyChoices
											WHERE Text = 'Yes'
											AND PropertyId = @IsAgencyId
										),
				                        @IsAgencyId, @OrgId
			                        );
									INSERT INTO OrganizationPropertyValues
									(
										CreationDateTime, LastChangeDateTime,
										CreationByUserId, LastChangeByUserId,
										ValueText, PropertyId, OrganizationId
									)
									VALUES
									(
										CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,
										@AdminUserId, @AdminUserId,
										@TASID, @OrgCodeId, @OrgId
									);
									INSERT INTO OrganizationPropertyValues
									(
										CreationDateTime, LastChangeDateTime,
										CreationByUserId, LastChangeByUserId,
										ValueText, PropertyId, OrganizationId
									)
									VALUES
									(
										CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,
										@AdminUserId, @AdminUserId,
										@County_Name, @CountyNameId, @OrgId
									);
									INSERT INTO OrganizationPropertyValues
									(
										CreationDateTime, LastChangeDateTime,
										CreationByUserId, LastChangeByUserId,
										ValueText, PropertyId, OrganizationId
									)
									VALUES
									(
										CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,
										@AdminUserId, @AdminUserId,
										@Provider_Type, @ProviderTypeId, @OrgId
									);
									INSERT INTO OrganizationPropertyValues
									(
										CreationDateTime, LastChangeDateTime,
										CreationByUserId, LastChangeByUserId,
										ValueText, PropertyId, OrganizationId
									)
									VALUES
									(
										CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,
										@AdminUserId, @AdminUserId,
										@Regulatory_Agency, @RegulatoryAgencyId, @OrgId
									);
									INSERT INTO OrganizationPropertyValues
									(
										CreationDateTime, LastChangeDateTime,
										CreationByUserId, LastChangeByUserId,
										ValueText, PropertyId, OrganizationId
									)
									VALUES
									(
										CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,
										@AdminUserId, @AdminUserId,
										@Regulatory_Status, @AgencyStatusId, @OrgId
									);
									IF @Regu_Individual is not null
									BEGIN
										INSERT INTO OrganizationPropertyValues
										(
											CreationDateTime, LastChangeDateTime,
											CreationByUserId, LastChangeByUserId,
											ValueText, PropertyId, OrganizationId
										)
										VALUES
										(
											CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,
											@AdminUserId, @AdminUserId,
											@Regu_Individual, @ReguIndividualId, @OrgId
										);
										INSERT INTO OrganizationPropertyValues
										(
											CreationDateTime, LastChangeDateTime,
											CreationByUserId, LastChangeByUserId,
											ValueText, PropertyId, OrganizationId
										)
										VALUES
										(
											CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,
											@AdminUserId, @AdminUserId,
											@Regu_Individual_Phone, @ReguIndividualPhoneId, @OrgId
										);
										INSERT INTO OrganizationPropertyValues
										(
											CreationDateTime, LastChangeDateTime,
											CreationByUserId, LastChangeByUserId,
											ValueText, PropertyId, OrganizationId
										)
										VALUES
										(
											CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,
											@AdminUserId, @AdminUserId,
											@Regu_Individual_Email, @ReguIndividualEmailId, @OrgId
										);
									END
									INSERT INTO OrganizationPropertyValues
									(
										CreationDateTime, LastChangeDateTime,
										CreationByUserId, LastChangeByUserId,
										ValueText, PropertyId, OrganizationId
									)
									VALUES
									(
										CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,
										@AdminUserId, @AdminUserId,
										@Location_Street_1, @LocationStreet1Id, @OrgId
									);
									INSERT INTO OrganizationPropertyValues
									(
										CreationDateTime, LastChangeDateTime,
										CreationByUserId, LastChangeByUserId,
										ValueText, PropertyId, OrganizationId
									)
									VALUES
									(
										CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,
										@AdminUserId, @AdminUserId,
										@Location_City, @LocationCityId, @OrgId
									);
									INSERT INTO OrganizationPropertyValues
									(
										CreationDateTime, LastChangeDateTime,
										CreationByUserId, LastChangeByUserId,
										ValueText, PropertyId, OrganizationId
									)
									VALUES
									(
										CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,
										@AdminUserId, @AdminUserId,
										@Location_State, @LocationStateId, @OrgId
									);
									INSERT INTO OrganizationPropertyValues
									(
										CreationDateTime, LastChangeDateTime,
										CreationByUserId, LastChangeByUserId,
										ValueText, PropertyId, OrganizationId
									)
									VALUES
									(
										CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,
										@AdminUserId, @AdminUserId,
										@Location_Zip, @LocationZipId, @OrgId
									);
									INSERT INTO OrganizationPropertyValues
									(
										CreationDateTime, LastChangeDateTime,
										CreationByUserId, LastChangeByUserId,
										ValueText, PropertyId, OrganizationId
									)
									VALUES
									(
										CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,
										@AdminUserId, @AdminUserId,
										@Region, @RegionId, @OrgId
									);
									INSERT INTO OrganizationPropertyValues
									(
										CreationDateTime, LastChangeDateTime,
										CreationByUserId, LastChangeByUserId,
										ValueText, PropertyId, OrganizationId
									)
									VALUES
									(
										CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,
										@AdminUserId, @AdminUserId,
										@SearchDisplayName, @SearchDisplayNameId, @OrgId
									);
								END
								ELSE
								BEGIN
									SELECT
										@CurName = OrganizationName,
				                        @isDisabled = Disabled
									FROM Organizations
									WHERE OrganizationId = @OrgId;
									IF(@CurName <> @Provider_Name OR @isDisabled <> @SetDisabled)
										UPDATE Organizations
										SET
											OrganizationName = @Provider_Name,
											Disabled = @SetDisabled,
											LastChangeDateTime = CURRENT_TIMESTAMP,
											LastChangeByUserId = @AdminUserId
										WHERE OrganizationId = @OrgId;
									SELECT
										@OPV = OrganizationPropertyValueId,
										@CurCounty = ValueText
									FROM OrganizationPropertyValues
									WHERE OrganizationId = @OrgId
										AND PropertyId = @CountyNameId;
									IF @OPV IS NOT null
										BEGIN
											IF @CurCounty != @County_Name
												UPDATE OrganizationPropertyValues
												SET ValueText = @County_Name,
													LastChangeByUserId = @AdminUserId,
													LastChangeDateTime = CURRENT_TIMESTAMP
												WHERE OrganizationPropertyValueId = @OPV;
										END
									ELSE
										INSERT INTO OrganizationPropertyValues
										(
											CreationDateTime, LastChangeDateTime,
											CreationByUserId, LastChangeByUserId,
											ValueText, PropertyId, OrganizationId
										)
										VALUES
										(
											CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,
											@AdminUserId, @AdminUserId,
											@County_Name, @CountyNameId, @OrgId
										);
									SELECT
										@OPV = OrganizationPropertyValueId,
										@CurProviderType = ValueText
									FROM OrganizationPropertyValues
									WHERE OrganizationId = @OrgId
										AND PropertyId = @ProviderTypeId;
									IF @OPV IS NOT null 
										BEGIN
											IF @CurProviderType != @Provider_Type
												UPDATE OrganizationPropertyValues
												SET ValueText = @Provider_Type,
													LastChangeByUserId = @AdminUserId,
													LastChangeDateTime = CURRENT_TIMESTAMP
												WHERE OrganizationPropertyValueId = @OPV;
										END
									ELSE
										INSERT INTO OrganizationPropertyValues
										(
											CreationDateTime, LastChangeDateTime,
											CreationByUserId, LastChangeByUserId,
											ValueText, PropertyId, OrganizationId
										)
										VALUES
										(
											CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,
											@AdminUserId, @AdminUserId,
											@Provider_Type, @ProviderTypeId, @OrgId
										);
									SELECT
										@OPV = OrganizationPropertyValueId,
										@CurRegulatoryAgency = ValueText
									FROM OrganizationPropertyValues
									WHERE OrganizationId = @OrgId
										AND PropertyId = @RegulatoryAgencyId;
									IF @OPV IS NOT null 
										BEGIN
											IF @CurRegulatoryAgency != @Regulatory_Agency
												UPDATE OrganizationPropertyValues
												SET ValueText = @Regulatory_Agency,
													LastChangeByUserId = @AdminUserId,
													LastChangeDateTime = CURRENT_TIMESTAMP
												WHERE OrganizationPropertyValueId = @OPV;
										END
									ELSE
										INSERT INTO OrganizationPropertyValues
										(
											CreationDateTime, LastChangeDateTime,
											CreationByUserId, LastChangeByUserId,
											ValueText, PropertyId, OrganizationId
										)
										VALUES
										(
											CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,
											@AdminUserId, @AdminUserId,
											@Regulatory_Agency, @RegulatoryAgencyId, @OrgId
										);
									SELECT
										@OPV = OrganizationPropertyValueId,
										@CurRegulatoryStatus = ValueText
									FROM OrganizationPropertyValues
									WHERE OrganizationId = @OrgId
										AND PropertyId = @AgencyStatusId;
									IF	@OPV IS NOT null 
										BEGIN
											IF @CurRegulatoryStatus != @Regulatory_Status
												UPDATE OrganizationPropertyValues
												SET ValueText = @Regulatory_Status,
													LastChangeByUserId = @AdminUserId,
													LastChangeDateTime = CURRENT_TIMESTAMP
												WHERE OrganizationPropertyValueId = @OPV;
										END
									ELSE
										INSERT INTO OrganizationPropertyValues
										(
											CreationDateTime, LastChangeDateTime,
											CreationByUserId, LastChangeByUserId,
											ValueText, PropertyId, OrganizationId
										)
										VALUES
										(
											CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,
											@AdminUserId, @AdminUserId,
											@Regulatory_Status, @AgencyStatusId, @OrgId
										);
									IF @Regu_Individual is not null
										BEGIN
											SELECT
												@OPV = OrganizationPropertyValueId,
												@CurReguIndividual = ValueText
											FROM OrganizationPropertyValues
											WHERE OrganizationId = @OrgId
												AND PropertyId = @ReguIndividualId;
											IF @OPV IS NOT null
												BEGIN
													IF @CurReguIndividual != @Regu_Individual
														UPDATE OrganizationPropertyValues
														SET ValueText = @Regu_Individual,
															LastChangeByUserId = @AdminUserId,
															LastChangeDateTime = CURRENT_TIMESTAMP
														WHERE OrganizationPropertyValueId = @OPV;
												END
											ELSE
												INSERT INTO OrganizationPropertyValues
												(
													CreationDateTime, LastChangeDateTime,
													CreationByUserId, LastChangeByUserId,
													ValueText, PropertyId, OrganizationId
												)
												VALUES
												(
													CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,
													@AdminUserId, @AdminUserId,
													@Regu_Individual, @ReguIndividualId, @OrgId
												);
											SELECT
												@OPV = OrganizationPropertyValueId,
												@CurReguIndividualPhone = ValueText
											FROM OrganizationPropertyValues
											WHERE OrganizationId = @OrgId
												AND PropertyId = @ReguIndividualPhoneId;
											IF @OPV IS NOT null
												BEGIN
													IF @CurReguIndividualPhone != @Regu_Individual_Phone
														UPDATE OrganizationPropertyValues
														SET ValueText = @Regu_Individual_Phone,
															LastChangeByUserId = @AdminUserId,
															LastChangeDateTime = CURRENT_TIMESTAMP
														WHERE OrganizationPropertyValueId = @OPV;
												END
											ELSE
												INSERT INTO OrganizationPropertyValues
												(
													CreationDateTime, LastChangeDateTime,
													CreationByUserId, LastChangeByUserId,
													ValueText, PropertyId, OrganizationId
												)
												VALUES
												(
													CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,
													@AdminUserId, @AdminUserId,
													@Regu_Individual_Phone, @ReguIndividualPhoneId, @OrgId
												);
											SELECT
												@OPV = OrganizationPropertyValueId,
												@CurReguIndividualEmail = ValueText
											FROM OrganizationPropertyValues
											WHERE OrganizationId = @OrgId
												AND PropertyId = @ReguIndividualEmailId;
											IF @OPV IS NOT null
												BEGIN
													IF @CurReguIndividualEmail != @Regu_Individual_Email
														UPDATE OrganizationPropertyValues
														SET ValueText = @Regu_Individual_Email,
															LastChangeByUserId = @AdminUserId,
															LastChangeDateTime = CURRENT_TIMESTAMP
														WHERE OrganizationPropertyValueId = @OPV;
												END
											ELSE
												INSERT INTO OrganizationPropertyValues
												(
													CreationDateTime, LastChangeDateTime,
													CreationByUserId, LastChangeByUserId,
													ValueText, PropertyId, OrganizationId
												)
												VALUES
												(
													CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,
													@AdminUserId, @AdminUserId,
													@Regu_Individual_Email, @ReguIndividualEmailId, @OrgId
												);
										END
									ELSE
										DELETE FROM OrganizationPropertyValues
											WHERE OrganizationId = @OrgId
											AND PropertyId IN (@ReguIndividualId, @ReguIndividualPhoneId, @ReguIndividualEmailId)
									SELECT
										@OPV = OrganizationPropertyValueId,
										@CurLocStreet1 = ValueText
									FROM OrganizationPropertyValues
									WHERE OrganizationId = @OrgId
										AND PropertyId = @LocationStreet1Id;
									IF @OPV IS NOT null 
										BEGIN
											IF @CurLocStreet1 != @Location_Street_1
												UPDATE OrganizationPropertyValues
												SET ValueText = @Location_Street_1,
													LastChangeByUserId = @AdminUserId,
													LastChangeDateTime = CURRENT_TIMESTAMP
												WHERE OrganizationPropertyValueId = @OPV;
										END
									ELSE
										INSERT INTO OrganizationPropertyValues
										(
											CreationDateTime, LastChangeDateTime,
											CreationByUserId, LastChangeByUserId,
											ValueText, PropertyId, OrganizationId
										)
										VALUES
										(
											CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,
											@AdminUserId, @AdminUserId,
											@Location_Street_1, @LocationStreet1Id, @OrgId
										);
									SELECT
										@OPV = OrganizationPropertyValueId,
										@CurCity = ValueText
									FROM OrganizationPropertyValues
									WHERE OrganizationId = @OrgId
										AND PropertyId = @LocationCityId;
									IF @OPV IS NOT null 
										BEGIN
											IF @CurCity != @Location_City
												UPDATE OrganizationPropertyValues
												SET ValueText = @Location_City,
													LastChangeByUserId = @AdminUserId,
													LastChangeDateTime = CURRENT_TIMESTAMP
												WHERE OrganizationPropertyValueId = @OPV;
										END
									ELSE
										INSERT INTO OrganizationPropertyValues
										(
											CreationDateTime, LastChangeDateTime,
											CreationByUserId, LastChangeByUserId,
											ValueText, PropertyId, OrganizationId
										)
										VALUES
										(
											CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,
											@AdminUserId, @AdminUserId,
											@Location_City, @LocationCityId, @OrgId
										);
									SELECT
										@OPV = OrganizationPropertyValueId,
										@CurState = ValueText
									FROM OrganizationPropertyValues
									WHERE OrganizationId = @OrgId
										AND PropertyId = @LocationStateId;
									IF @OPV IS NOT null 
										BEGIN
											IF @CurState != @Location_State
												UPDATE OrganizationPropertyValues
												SET ValueText = @Location_State,
													LastChangeByUserId = @AdminUserId,
													LastChangeDateTime = CURRENT_TIMESTAMP
												WHERE OrganizationPropertyValueId = @OPV;
										END
									ELSE
										INSERT INTO OrganizationPropertyValues
										(
											CreationDateTime, LastChangeDateTime,
											CreationByUserId, LastChangeByUserId,
											ValueText, PropertyId, OrganizationId
										)
										VALUES
										(
											CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,
											@AdminUserId, @AdminUserId,
											@Location_State, @LocationStateId, @OrgId
										);
									SELECT
										@OPV = OrganizationPropertyValueId,
										@CurZip = ValueText
									FROM OrganizationPropertyValues
									WHERE OrganizationId = @OrgId
										AND PropertyId = @LocationZipId;
									IF	@OPV IS NOT null 
										BEGIN
											IF @CurZip != @Location_Zip
												UPDATE OrganizationPropertyValues
												SET ValueText = @Location_Zip,
													LastChangeByUserId = @AdminUserId,
													LastChangeDateTime = CURRENT_TIMESTAMP
												WHERE OrganizationPropertyValueId = @OPV;
										END
									ELSE
										INSERT INTO OrganizationPropertyValues
										(
											CreationDateTime, LastChangeDateTime,
											CreationByUserId, LastChangeByUserId,
											ValueText, PropertyId, OrganizationId
										)
										VALUES
										(
											CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,
											@AdminUserId, @AdminUserId,
											@Location_Zip, @LocationZipId, @OrgId
										);
									SELECT
										@OPV = OrganizationPropertyValueId,
										@CurRegion = ValueText
									FROM OrganizationPropertyValues
									WHERE OrganizationId = @OrgId
										AND PropertyId = @RegionId;
									IF @OPV IS NOT null 
										BEGIN
											IF @CurRegion != @Region
												UPDATE OrganizationPropertyValues
												SET ValueText = @Region,
													LastChangeByUserId = @AdminUserId,
													LastChangeDateTime = CURRENT_TIMESTAMP
												WHERE OrganizationPropertyValueId = @OPV;
										END
									ELSE
										INSERT INTO OrganizationPropertyValues
										(
											CreationDateTime, LastChangeDateTime,
											CreationByUserId, LastChangeByUserId,
											ValueText, PropertyId, OrganizationId
										)
										VALUES
										(
											CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,
											@AdminUserId, @AdminUserId,
											@Region, @RegionId, @OrgId
										);
									SELECT
										@OPV = OrganizationPropertyValueId,
										@CurSearchDisplayName = ValueText
									FROM OrganizationPropertyValues
									WHERE OrganizationId = @OrgId
										AND PropertyId = @SearchDisplayNameId;
									IF	@OPV IS NOT null
										BEGIN
											IF @CurSearchDisplayName != @SearchDisplayName
												UPDATE OrganizationPropertyValues
												SET ValueText = @SearchDisplayName,
													LastChangeByUserId = @AdminUserId,
													LastChangeDateTime = CURRENT_TIMESTAMP
												WHERE OrganizationPropertyValueId = @OPV;
										END
									ELSE
										INSERT INTO OrganizationPropertyValues
										(
											CreationDateTime, LastChangeDateTime,
											CreationByUserId, LastChangeByUserId,
											ValueText, PropertyId, OrganizationId
										)
										VALUES
										(
											CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,
											@AdminUserId, @AdminUserId,
											@SearchDisplayName, @SearchDisplayNameId, @OrgId
										);
								END

								FETCH NEXT FROM agency_cursor
									INTO
										@TASID, @Provider_Name, @County_Name, @ProvTypeCode,
										@Regulatory_Agency, @RegStatCode, @Regu_Individual,
										@Regu_Individual_Phone, @Regu_Individual_Email,
										@Location_Street_1, @Location_City, @Location_State, 
										@Location_Zip, @RegionCode

							END

							CLOSE agency_cursor
							DEALLOCATE agency_cursor
				RETURN 0;
			END
GO
