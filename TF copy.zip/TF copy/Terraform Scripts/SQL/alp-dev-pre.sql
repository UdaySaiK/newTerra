USE [wfr_al_dev]
GO
/****** Object:  Table [audit].[AlertDismissals]    Script Date: 8/14/2024 9:16:09 AM ******/

/****** Object:  Table [dbo].[__EFMigrationsHistory]    Script Date: 8/14/2024 9:16:09 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[__EFMigrationsHistory](
	[MigrationId] [nvarchar](150) NOT NULL,
	[ProductVersion] [nvarchar](32) NOT NULL,
 CONSTRAINT [PK___EFMigrationsHistory] PRIMARY KEY CLUSTERED 
(
	[MigrationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[AlertDismissals]    Script Date: 8/14/2024 9:16:09 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AlertDismissals](
	[AlertDismissalId] [nvarchar](450) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](450) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[AlertId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_AlertDismissals] PRIMARY KEY CLUSTERED 
(
	[AlertDismissalId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[AlertPropertyValues]    Script Date: 8/14/2024 9:16:09 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AlertPropertyValues](
	[AlertPropertyValueId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[ValueText] [nvarchar](max) NULL,
	[ValueDate] [datetime2](7) NULL,
	[ValueInt] [bigint] NULL,
	[ValueFloat] [real] NULL,
	[PropertyId] [bigint] NOT NULL,
	[AlertId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_AlertPropertyValues] PRIMARY KEY CLUSTERED 
(
	[AlertPropertyValueId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Alerts]    Script Date: 8/14/2024 9:16:09 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Alerts](
	[AlertId] [nvarchar](450) NOT NULL,
	[Dismissible] [nvarchar](max) NULL,
	[ExpireDateTime] [datetime2](7) NULL,
	[StartDateTime] [datetime2](7) NULL,
	[Subject] [nvarchar](max) NULL,
	[Message] [nvarchar](max) NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[Disabled] [bit] NOT NULL,
 CONSTRAINT [PK_Alerts] PRIMARY KEY CLUSTERED 
(
	[AlertId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ApplicationLog]    Script Date: 8/14/2024 9:16:09 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ApplicationLog](
	[ApplicationLogID] [int] IDENTITY(1,1) NOT NULL,
	[MachineName] [nvarchar](200) NULL,
	[Logged] [datetime] NOT NULL,
	[Level] [varchar](5) NOT NULL,
	[Message] [nvarchar](max) NOT NULL,
	[Logger] [nvarchar](300) NULL,
	[Properties] [nvarchar](max) NULL,
	[Callsite] [nvarchar](300) NULL,
	[Exception] [nvarchar](max) NULL,
	[ApplicationLogGuid] [nvarchar](450) NULL,
 CONSTRAINT [PK_ApplicationLog] PRIMARY KEY CLUSTERED 
(
	[ApplicationLogID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[AspNetRoleClaims]    Script Date: 8/14/2024 9:16:09 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AspNetRoleClaims](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[RoleId] [nvarchar](450) NOT NULL,
	[ClaimType] [nvarchar](max) NULL,
	[ClaimValue] [nvarchar](max) NULL,
 CONSTRAINT [PK_AspNetRoleClaims] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[AspNetRoles]    Script Date: 8/14/2024 9:16:09 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AspNetRoles](
	[Id] [nvarchar](450) NOT NULL,
	[Name] [nvarchar](256) NULL,
	[NormalizedName] [nvarchar](256) NULL,
	[ConcurrencyStamp] [nvarchar](max) NULL,
	[Rank] [int] NOT NULL,
 CONSTRAINT [PK_AspNetRoles] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[AspNetUserClaims]    Script Date: 8/14/2024 9:16:09 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AspNetUserClaims](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[UserId] [nvarchar](450) NOT NULL,
	[ClaimType] [nvarchar](max) NULL,
	[ClaimValue] [nvarchar](max) NULL,
 CONSTRAINT [PK_AspNetUserClaims] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[AspNetUserLogins]    Script Date: 8/14/2024 9:16:09 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AspNetUserLogins](
	[LoginProvider] [nvarchar](450) NOT NULL,
	[ProviderKey] [nvarchar](450) NOT NULL,
	[ProviderDisplayName] [nvarchar](max) NULL,
	[UserId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_AspNetUserLogins] PRIMARY KEY CLUSTERED 
(
	[LoginProvider] ASC,
	[ProviderKey] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[AspNetUserRoles]    Script Date: 8/14/2024 9:16:09 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AspNetUserRoles](
	[UserId] [nvarchar](450) NOT NULL,
	[RoleId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_AspNetUserRoles] PRIMARY KEY CLUSTERED 
(
	[UserId] ASC,
	[RoleId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[AspNetUsers]    Script Date: 8/14/2024 9:16:09 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AspNetUsers](
	[Id] [nvarchar](450) NOT NULL,
	[UserName] [nvarchar](256) NULL,
	[NormalizedUserName] [nvarchar](256) NULL,
	[Email] [nvarchar](256) NULL,
	[NormalizedEmail] [nvarchar](256) NULL,
	[EmailConfirmed] [bit] NOT NULL,
	[PasswordHash] [nvarchar](max) NULL,
	[SecurityStamp] [nvarchar](max) NULL,
	[ConcurrencyStamp] [nvarchar](max) NULL,
	[PhoneNumber] [nvarchar](max) NULL,
	[PhoneNumberConfirmed] [bit] NOT NULL,
	[TwoFactorEnabled] [bit] NOT NULL,
	[LockoutEnd] [datetimeoffset](7) NULL,
	[LockoutEnabled] [bit] NOT NULL,
	[AccessFailedCount] [int] NOT NULL,
	[FirstName] [nvarchar](max) NULL,
	[LastName] [nvarchar](max) NULL,
	[TacAcceptedDate] [datetime2](7) NULL,
	[Disabled] [bit] NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
 CONSTRAINT [PK_AspNetUsers] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[AspNetUserTokens]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AspNetUserTokens](
	[UserId] [nvarchar](450) NOT NULL,
	[LoginProvider] [nvarchar](450) NOT NULL,
	[Name] [nvarchar](450) NOT NULL,
	[Value] [nvarchar](max) NULL,
 CONSTRAINT [PK_AspNetUserTokens] PRIMARY KEY CLUSTERED 
(
	[UserId] ASC,
	[LoginProvider] ASC,
	[Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[AwardRecordPropertyValues]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AwardRecordPropertyValues](
	[AwardRecordPropertyValueId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[ValueText] [nvarchar](max) NULL,
	[ValueDate] [datetime2](7) NULL,
	[ValueInt] [bigint] NULL,
	[ValueFloat] [real] NULL,
	[PropertyId] [bigint] NOT NULL,
	[AwardRecordId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_AwardRecordPropertyValues] PRIMARY KEY CLUSTERED 
(
	[AwardRecordPropertyValueId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[AwardRecords]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AwardRecords](
	[AwardRecordId] [nvarchar](450) NOT NULL,
	[AwardName] [nvarchar](max) NULL,
	[Disabled] [bit] NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[PrimaryEntityId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_AwardRecords] PRIMARY KEY CLUSTERED 
(
	[AwardRecordId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CareerLatticeRecordPropertyValues]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CareerLatticeRecordPropertyValues](
	[CareerLatticeRecordPropertyValueId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[ValueText] [nvarchar](max) NULL,
	[ValueDate] [datetime2](7) NULL,
	[ValueInt] [bigint] NULL,
	[ValueFloat] [real] NULL,
	[PropertyId] [bigint] NOT NULL,
	[CareerLatticeRecordId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_CareerLatticeRecordPropertyValues] PRIMARY KEY CLUSTERED 
(
	[CareerLatticeRecordPropertyValueId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CareerLatticeRecords]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CareerLatticeRecords](
	[CareerLatticeRecordId] [nvarchar](450) NOT NULL,
	[PrimaryEntityId] [nvarchar](450) NOT NULL,
	[Disabled] [bit] NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
 CONSTRAINT [PK_CareerLatticeRecords] PRIMARY KEY CLUSTERED 
(
	[CareerLatticeRecordId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CertificationRecordPropertyValues]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CertificationRecordPropertyValues](
	[CertificationRecordPropertyValueId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[ValueText] [nvarchar](max) NULL,
	[ValueDate] [datetime2](7) NULL,
	[ValueInt] [bigint] NULL,
	[ValueFloat] [real] NULL,
	[PropertyId] [bigint] NOT NULL,
	[CertificationRecordId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_CertificationRecordPropertyValues] PRIMARY KEY CLUSTERED 
(
	[CertificationRecordPropertyValueId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CertificationRecords]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CertificationRecords](
	[CertificationRecordId] [nvarchar](450) NOT NULL,
	[CertificationName] [nvarchar](max) NULL,
	[AwardingInstitution] [nvarchar](max) NULL,
	[Disabled] [bit] NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[PrimaryEntityId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_CertificationRecords] PRIMARY KEY CLUSTERED 
(
	[CertificationRecordId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CertRules]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CertRules](
	[CertRuleId] [nvarchar](450) NOT NULL,
	[RuleId] [nvarchar](450) NOT NULL,
	[CertPattern] [nvarchar](max) NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[Disabled] [bit] NOT NULL,
	[Ambiguous] [bit] NOT NULL,
 CONSTRAINT [PK_CertRules] PRIMARY KEY CLUSTERED 
(
	[CertRuleId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CoachRelationshipActions]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CoachRelationshipActions](
	[CoachRelationshipActionId] [nvarchar](450) NOT NULL,
	[PrimaryEntityId] [nvarchar](450) NOT NULL,
	[CoachId] [nvarchar](450) NOT NULL,
	[ActionType] [int] NOT NULL,
	[Comments] [nvarchar](max) NULL,
	[ParentActionId] [nvarchar](max) NULL,
	[CoachRelationshipId] [nvarchar](450) NULL,
	[ExpirationDate] [datetime2](7) NULL,
	[Disabled] [bit] NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
 CONSTRAINT [PK_CoachRelationshipActions] PRIMARY KEY CLUSTERED 
(
	[CoachRelationshipActionId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CoachRelationships]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CoachRelationships](
	[CoachRelationshipId] [nvarchar](450) NOT NULL,
	[PrimaryEntityId] [nvarchar](450) NOT NULL,
	[CoachId] [nvarchar](450) NOT NULL,
	[PdpShared] [bit] NOT NULL,
	[StartDate] [datetime2](7) NOT NULL,
	[EndDate] [datetime2](7) NULL,
	[Disabled] [bit] NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
 CONSTRAINT [PK_CoachRelationships] PRIMARY KEY CLUSTERED 
(
	[CoachRelationshipId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CommentPropertyValues]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CommentPropertyValues](
	[CommentPropertyValueId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[ValueText] [nvarchar](max) NULL,
	[ValueDate] [datetime2](7) NULL,
	[ValueInt] [bigint] NULL,
	[ValueFloat] [real] NULL,
	[PropertyId] [bigint] NOT NULL,
	[CommentId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_CommentPropertyValues] PRIMARY KEY CLUSTERED 
(
	[CommentPropertyValueId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Comments]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Comments](
	[CommentId] [nvarchar](450) NOT NULL,
	[EntityTypeId] [bigint] NOT NULL,
	[EntityId] [nvarchar](450) NOT NULL,
	[PrimaryEntityId] [nvarchar](450) NOT NULL,
	[Content] [nvarchar](max) NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[Disabled] [bit] NOT NULL,
 CONSTRAINT [PK_Comments] PRIMARY KEY CLUSTERED 
(
	[CommentId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CommunityServiceRecordPropertyValues]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CommunityServiceRecordPropertyValues](
	[CommunityServiceRecordPropertyValueId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[ValueText] [nvarchar](max) NULL,
	[ValueDate] [datetime2](7) NULL,
	[ValueInt] [bigint] NULL,
	[ValueFloat] [real] NULL,
	[PropertyId] [bigint] NOT NULL,
	[CommunityServiceRecordId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_CommunityServiceRecordPropertyValues] PRIMARY KEY CLUSTERED 
(
	[CommunityServiceRecordPropertyValueId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CommunityServiceRecords]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CommunityServiceRecords](
	[CommunityServiceRecordId] [nvarchar](450) NOT NULL,
	[CommunityServiceName] [nvarchar](max) NULL,
	[Disabled] [bit] NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[PrimaryEntityId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_CommunityServiceRecords] PRIMARY KEY CLUSTERED 
(
	[CommunityServiceRecordId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CourseMeetingRecordPropertyValues]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CourseMeetingRecordPropertyValues](
	[CourseMeetingRecordPropertyValueId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[ValueText] [nvarchar](max) NULL,
	[ValueDate] [datetime2](7) NULL,
	[ValueInt] [bigint] NULL,
	[ValueFloat] [real] NULL,
	[PropertyId] [bigint] NOT NULL,
	[CourseMeetingRecordId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_CourseMeetingRecordPropertyValues] PRIMARY KEY CLUSTERED 
(
	[CourseMeetingRecordPropertyValueId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CourseMeetingRecords]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CourseMeetingRecords](
	[CourseMeetingRecordId] [nvarchar](450) NOT NULL,
	[CourseMeetingName] [nvarchar](max) NULL,
	[Disabled] [bit] NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CourseSectionRecordId] [nvarchar](450) NOT NULL,
	[CourseMeetingStart] [datetime2](7) NOT NULL,
	[CourseMeetingEnd] [datetime2](7) NOT NULL,
	[CourseMeetingTrainerName] [nvarchar](450) NULL,
 CONSTRAINT [PK_CourseMeetingRecords] PRIMARY KEY CLUSTERED 
(
	[CourseMeetingRecordId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CourseRecordPropertyValues]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CourseRecordPropertyValues](
	[CourseRecordPropertyValueId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[ValueText] [nvarchar](max) NULL,
	[ValueDate] [datetime2](7) NULL,
	[ValueInt] [bigint] NULL,
	[ValueFloat] [real] NULL,
	[PropertyId] [bigint] NOT NULL,
	[CourseRecordId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_CourseRecordPropertyValues] PRIMARY KEY CLUSTERED 
(
	[CourseRecordPropertyValueId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CourseRecords]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CourseRecords](
	[CourseRecordId] [nvarchar](450) NOT NULL,
	[CourseName] [nvarchar](450) NOT NULL,
	[Disabled] [bit] NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CourseOwnerId] [nvarchar](450) NOT NULL,
	[CourseOwnerOrgName] [nvarchar](450) NULL,
 CONSTRAINT [PK_CourseRecords] PRIMARY KEY CLUSTERED 
(
	[CourseRecordId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CourseSectionRecordPropertyValues]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CourseSectionRecordPropertyValues](
	[CourseSectionRecordPropertyValueId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[ValueText] [nvarchar](max) NULL,
	[ValueDate] [datetime2](7) NULL,
	[ValueInt] [bigint] NULL,
	[ValueFloat] [real] NULL,
	[PropertyId] [bigint] NOT NULL,
	[CourseSectionRecordId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_CourseSectionRecordPropertyValues] PRIMARY KEY CLUSTERED 
(
	[CourseSectionRecordPropertyValueId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CourseSectionRecords]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CourseSectionRecords](
	[CourseSectionRecordId] [nvarchar](450) NOT NULL,
	[CourseSectionName] [nvarchar](450) NOT NULL,
	[Disabled] [bit] NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CourseRecordId] [nvarchar](450) NOT NULL,
	[CourseSectionOwnerId] [nvarchar](450) NOT NULL,
	[CourseSectionOwnerOrgName] [nvarchar](450) NULL,
	[CourseSectionStart] [datetime2](7) NOT NULL,
	[CourseSectionEnd] [datetime2](7) NOT NULL,
	[CourseSectionMaxEnrollment] [bigint] NOT NULL,
	[CourseSectionCurrentEnrollment] [bigint] NOT NULL,
 CONSTRAINT [PK_CourseSectionRecords] PRIMARY KEY CLUSTERED 
(
	[CourseSectionRecordId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DataProtectionKeys]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DataProtectionKeys](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[FriendlyName] [nvarchar](max) NULL,
	[Xml] [nvarchar](max) NULL,
 CONSTRAINT [PK_DataProtectionKeys] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[EducationRecordPropertyValues]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EducationRecordPropertyValues](
	[EducationRecordPropertyValueId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[ValueText] [nvarchar](max) NULL,
	[ValueDate] [datetime2](7) NULL,
	[ValueInt] [bigint] NULL,
	[ValueFloat] [real] NULL,
	[PropertyId] [bigint] NOT NULL,
	[EducationRecordId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_EducationRecordPropertyValues] PRIMARY KEY CLUSTERED 
(
	[EducationRecordPropertyValueId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[EducationRecords]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EducationRecords](
	[EducationRecordId] [nvarchar](450) NOT NULL,
	[SchoolName] [nvarchar](max) NULL,
	[Major] [nvarchar](max) NULL,
	[Disabled] [bit] NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[PrimaryEntityId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_EducationRecords] PRIMARY KEY CLUSTERED 
(
	[EducationRecordId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[EduRules]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EduRules](
	[EduRuleId] [nvarchar](450) NOT NULL,
	[RuleId] [nvarchar](450) NOT NULL,
	[EduPattern] [nvarchar](max) NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[Disabled] [bit] NOT NULL,
	[Ambiguous] [bit] NOT NULL,
 CONSTRAINT [PK_EduRules] PRIMARY KEY CLUSTERED 
(
	[EduRuleId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[EmploymentRecordPropertyValues]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EmploymentRecordPropertyValues](
	[EmploymentRecordPropertyValueId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[ValueText] [nvarchar](max) NULL,
	[ValueDate] [datetime2](7) NULL,
	[ValueInt] [bigint] NULL,
	[ValueFloat] [real] NULL,
	[PropertyId] [bigint] NOT NULL,
	[EmploymentRecordId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_EmploymentRecordPropertyValues] PRIMARY KEY CLUSTERED 
(
	[EmploymentRecordPropertyValueId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[EmploymentRecords]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EmploymentRecords](
	[EmploymentRecordId] [nvarchar](450) NOT NULL,
	[EmployerName] [nvarchar](450) NOT NULL,
	[Disabled] [bit] NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[PrimaryEntityId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_EmploymentRecords] PRIMARY KEY CLUSTERED 
(
	[EmploymentRecordId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[EnrollmentActions]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EnrollmentActions](
	[EnrollmentActionId] [nvarchar](450) NOT NULL,
	[EnrollmentRecordId] [nvarchar](450) NOT NULL,
	[Disabled] [bit] NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_EnrollmentActions] PRIMARY KEY CLUSTERED 
(
	[EnrollmentActionId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[EnrollmentRecordPropertyValues]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EnrollmentRecordPropertyValues](
	[EnrollmentRecordPropertyValueId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[ValueText] [nvarchar](max) NULL,
	[ValueDate] [datetime2](7) NULL,
	[ValueInt] [bigint] NULL,
	[ValueFloat] [real] NULL,
	[PropertyId] [bigint] NOT NULL,
	[EnrollmentRecordId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_EnrollmentRecordPropertyValues] PRIMARY KEY CLUSTERED 
(
	[EnrollmentRecordPropertyValueId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[EnrollmentRecords]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EnrollmentRecords](
	[EnrollmentRecordId] [nvarchar](450) NOT NULL,
	[Disabled] [bit] NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[PrimaryEntityId] [nvarchar](450) NOT NULL,
	[CourseSectionRecordId] [nvarchar](450) NOT NULL,
	[EnrollmentActionStatus] [int] NOT NULL,
 CONSTRAINT [PK_EnrollmentRecords] PRIMARY KEY CLUSTERED 
(
	[EnrollmentRecordId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[EntityTypeProperties]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EntityTypeProperties](
	[EntityTypePropertyId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[BaseColumnName] [nvarchar](max) NULL,
	[EntityTypeId] [bigint] NOT NULL,
	[PropertyId] [bigint] NOT NULL,
	[FallbackEntityTypePropertyId] [bigint] NULL,
	[HideInExport] [bit] NOT NULL,
 CONSTRAINT [PK_EntityTypeProperties] PRIMARY KEY CLUSTERED 
(
	[EntityTypePropertyId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[EntityTypes]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EntityTypes](
	[EntityTypeId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[Name] [nvarchar](max) NULL,
	[Description] [nvarchar](max) NULL,
	[Alias] [nvarchar](max) NULL,
	[BaseTable] [nvarchar](max) NULL,
 CONSTRAINT [PK_EntityTypes] PRIMARY KEY CLUSTERED 
(
	[EntityTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[FeedbackRecordPropertyValues]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[FeedbackRecordPropertyValues](
	[FeedbackRecordPropertyValueId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[ValueText] [nvarchar](max) NULL,
	[ValueDate] [datetime2](7) NULL,
	[ValueInt] [bigint] NULL,
	[ValueFloat] [real] NULL,
	[PropertyId] [bigint] NOT NULL,
	[FeedbackRecordId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_FeedbackRecordPropertyValues] PRIMARY KEY CLUSTERED 
(
	[FeedbackRecordPropertyValueId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[FeedbackRecords]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[FeedbackRecords](
	[FeedbackRecordId] [nvarchar](450) NOT NULL,
	[Disabled] [bit] NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[PrimaryEntityId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_FeedbackRecords] PRIMARY KEY CLUSTERED 
(
	[FeedbackRecordId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[FileInfo]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[FileInfo](
	[FileInfoId] [nvarchar](450) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](450) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[FileName] [nvarchar](max) NULL,
	[FileType] [nvarchar](max) NULL,
	[FileSizeInBytes] [bigint] NOT NULL,
	[FileSetId] [nvarchar](450) NULL,
	[EntityTypePropertyId] [bigint] NULL,
	[FileCode] [nvarchar](450) NULL,
	[IsStatic] [bit] NOT NULL,
 CONSTRAINT [PK_FileInfo] PRIMARY KEY CLUSTERED 
(
	[FileInfoId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[FormElementChoiceGroups]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[FormElementChoiceGroups](
	[FormElementChoiceGroupId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[FirstChoiceSequence] [int] NOT NULL,
	[GroupName] [nvarchar](max) NULL,
	[Disabled] [bit] NOT NULL,
	[FormElementId] [bigint] NOT NULL,
 CONSTRAINT [PK_FormElementChoiceGroups] PRIMARY KEY CLUSTERED 
(
	[FormElementChoiceGroupId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[FormElementChoices]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[FormElementChoices](
	[FormElementChoiceId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[Sequence] [int] NOT NULL,
	[Disabled] [bit] NOT NULL,
	[FormElementId] [bigint] NOT NULL,
	[PropertyChoiceId] [bigint] NOT NULL,
 CONSTRAINT [PK_FormElementChoices] PRIMARY KEY CLUSTERED 
(
	[FormElementChoiceId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[FormElementProperties]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[FormElementProperties](
	[FormElementPropertyId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[FormElementId] [bigint] NOT NULL,
	[PropertyId] [bigint] NOT NULL,
 CONSTRAINT [PK_FormElementProperties] PRIMARY KEY CLUSTERED 
(
	[FormElementPropertyId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[FormElements]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[FormElements](
	[FormElementId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[Stimulus] [nvarchar](max) NULL,
	[Required] [bit] NOT NULL,
	[Disabled] [bit] NOT NULL,
	[Width] [int] NULL,
	[MaxLength] [int] NULL,
	[Regex] [nvarchar](max) NULL,
	[WarningMessage] [nvarchar](max) NULL,
	[Sequence] [int] NOT NULL,
	[FormId] [bigint] NOT NULL,
	[FormElementTypeId] [bigint] NOT NULL,
	[FormElementSubTypeId] [bigint] NULL,
	[ReadOnly] [bit] NOT NULL,
	[Offset] [int] NULL,
	[Tooltip] [nvarchar](max) NULL,
	[Arguments] [nvarchar](max) NULL,
 CONSTRAINT [PK_FormElements] PRIMARY KEY CLUSTERED 
(
	[FormElementId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[FormElementSubTypes]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[FormElementSubTypes](
	[FormElementSubTypeId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[Name] [nvarchar](max) NULL,
	[Description] [nvarchar](max) NULL,
	[FormElementTypeId] [bigint] NOT NULL,
 CONSTRAINT [PK_FormElementSubTypes] PRIMARY KEY CLUSTERED 
(
	[FormElementSubTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[FormElementTypes]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[FormElementTypes](
	[FormElementTypeId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[Name] [nvarchar](max) NULL,
	[Description] [nvarchar](max) NULL,
 CONSTRAINT [PK_FormElementTypes] PRIMARY KEY CLUSTERED 
(
	[FormElementTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[FormResponseLogs]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[FormResponseLogs](
	[FormResponseLogId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[FormId] [bigint] NOT NULL,
 CONSTRAINT [PK_FormResponseLogs] PRIMARY KEY CLUSTERED 
(
	[FormResponseLogId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Forms]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Forms](
	[FormId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[Name] [nvarchar](max) NULL,
	[Description] [nvarchar](max) NULL,
	[Arguments] [nvarchar](max) NULL,
	[ExportCreatedBy] [bit] NOT NULL,
	[ExportCreatedDate] [bit] NOT NULL,
	[ExportLastUpdatedBy] [bit] NOT NULL,
	[ExportLastUpdatedDate] [bit] NOT NULL,
 CONSTRAINT [PK_Forms] PRIMARY KEY CLUSTERED 
(
	[FormId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[LoginHistories]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[LoginHistories](
	[LoginHistoryId] [nvarchar](450) NOT NULL,
	[UserId] [nvarchar](450) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[IpAddress] [nvarchar](max) NULL,
	[LoginHistoryType] [int] NOT NULL,
	[Details] [nvarchar](max) NULL,
 CONSTRAINT [PK_LoginHistories] PRIMARY KEY CLUSTERED 
(
	[LoginHistoryId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[MembershipRecordPropertyValues]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[MembershipRecordPropertyValues](
	[MembershipRecordPropertyValueId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[ValueText] [nvarchar](max) NULL,
	[ValueDate] [datetime2](7) NULL,
	[ValueInt] [bigint] NULL,
	[ValueFloat] [real] NULL,
	[PropertyId] [bigint] NOT NULL,
	[MembershipRecordId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_MembershipRecordPropertyValues] PRIMARY KEY CLUSTERED 
(
	[MembershipRecordPropertyValueId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[MembershipRecords]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[MembershipRecords](
	[MembershipRecordId] [nvarchar](450) NOT NULL,
	[MembershipOrganizationName] [nvarchar](max) NULL,
	[Disabled] [bit] NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[PrimaryEntityId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_MembershipRecords] PRIMARY KEY CLUSTERED 
(
	[MembershipRecordId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[MessageContents]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[MessageContents](
	[MessageContentId] [nvarchar](450) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[Subject] [nvarchar](max) NULL,
	[Body] [nvarchar](max) NULL,
	[LinkText] [nvarchar](max) NULL,
	[Route] [nvarchar](max) NULL,
 CONSTRAINT [PK_MessageContents] PRIMARY KEY CLUSTERED 
(
	[MessageContentId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Notifications]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Notifications](
	[NotificationId] [nvarchar](450) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[UserId] [nvarchar](450) NULL,
	[MessageContentId] [nvarchar](450) NOT NULL,
	[Archived] [bit] NOT NULL,
	[Read] [bit] NOT NULL,
	[Starred] [bit] NOT NULL,
 CONSTRAINT [PK_Notifications] PRIMARY KEY CLUSTERED 
(
	[NotificationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[NotificationTemplates]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[NotificationTemplates](
	[NotificationTemplateId] [nvarchar](450) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[SubjectTemplate] [nvarchar](max) NULL,
	[BodyTemplate] [nvarchar](max) NULL,
	[Disabled] [bit] NOT NULL,
	[LinkTextTemplate] [nvarchar](max) NULL,
	[RouteTemplate] [nvarchar](max) NULL,
 CONSTRAINT [PK_NotificationTemplates] PRIMARY KEY CLUSTERED 
(
	[NotificationTemplateId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[NotificationTriggers]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[NotificationTriggers](
	[NotificationTriggerId] [nvarchar](450) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[Trigger] [int] NOT NULL,
	[RoleId] [nvarchar](450) NOT NULL,
	[TemplateNotificationTemplateId] [nvarchar](450) NOT NULL,
	[LimitToActiveOrganization] [bit] NOT NULL,
	[Disabled] [bit] NOT NULL,
	[SendEmail] [bit] NOT NULL,
 CONSTRAINT [PK_NotificationTriggers] PRIMARY KEY CLUSTERED 
(
	[NotificationTriggerId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[OrganizationPropertyValues]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[OrganizationPropertyValues](
	[OrganizationPropertyValueId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[ValueText] [nvarchar](max) NULL,
	[ValueDate] [datetime2](7) NULL,
	[ValueInt] [bigint] NULL,
	[ValueFloat] [real] NULL,
	[PropertyId] [bigint] NOT NULL,
	[OrganizationId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_OrganizationPropertyValues] PRIMARY KEY CLUSTERED 
(
	[OrganizationPropertyValueId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Organizations]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Organizations](
	[OrganizationId] [nvarchar](450) NOT NULL,
	[OrganizationName] [nvarchar](max) NULL,
	[Disabled] [bit] NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
 CONSTRAINT [PK_Organizations] PRIMARY KEY CLUSTERED 
(
	[OrganizationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[PartnerNotificationLogs]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PartnerNotificationLogs](
	[PartnerNotificationLogId] [bigint] IDENTITY(1,1) NOT NULL,
	[PartnerNotificationType] [nvarchar](max) NULL,
	[Arguments] [nvarchar](max) NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[EmailSubject] [nvarchar](max) NULL,
 CONSTRAINT [PK_PartnerNotificationLogs] PRIMARY KEY CLUSTERED 
(
	[PartnerNotificationLogId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[PDPGoalRecordPropertyValues]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PDPGoalRecordPropertyValues](
	[PDPGoalRecordPropertyValueId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[ValueText] [nvarchar](max) NULL,
	[ValueDate] [datetime2](7) NULL,
	[ValueInt] [bigint] NULL,
	[ValueFloat] [real] NULL,
	[PropertyId] [bigint] NOT NULL,
	[PDPGoalRecordId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_PDPGoalRecordPropertyValues] PRIMARY KEY CLUSTERED 
(
	[PDPGoalRecordPropertyValueId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[PDPGoalRecords]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PDPGoalRecords](
	[PDPGoalRecordId] [nvarchar](450) NOT NULL,
	[PDPGoalName] [nvarchar](max) NULL,
	[Disabled] [bit] NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[PrimaryEntityId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_PDPGoalRecords] PRIMARY KEY CLUSTERED 
(
	[PDPGoalRecordId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[PDPRequiredTrainingRecordPropertyValues]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PDPRequiredTrainingRecordPropertyValues](
	[PDPRequiredTrainingRecordPropertyValueId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[ValueText] [nvarchar](max) NULL,
	[ValueDate] [datetime2](7) NULL,
	[ValueInt] [bigint] NULL,
	[ValueFloat] [real] NULL,
	[PropertyId] [bigint] NOT NULL,
	[PDPRequiredTrainingRecordId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_PDPRequiredTrainingRecordPropertyValues] PRIMARY KEY CLUSTERED 
(
	[PDPRequiredTrainingRecordPropertyValueId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[PDPRequiredTrainingRecords]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PDPRequiredTrainingRecords](
	[PDPRequiredTrainingRecordId] [nvarchar](450) NOT NULL,
	[Disabled] [bit] NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[PrimaryEntityId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_PDPRequiredTrainingRecords] PRIMARY KEY CLUSTERED 
(
	[PDPRequiredTrainingRecordId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[PDPSelfAssessmentRecordPropertyValues]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PDPSelfAssessmentRecordPropertyValues](
	[PDPSelfAssessmentRecordPropertyValueId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[ValueText] [nvarchar](max) NULL,
	[ValueDate] [datetime2](7) NULL,
	[ValueInt] [bigint] NULL,
	[ValueFloat] [real] NULL,
	[PropertyId] [bigint] NOT NULL,
	[PDPSelfAssessmentRecordId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_PDPSelfAssessmentRecordPropertyValues] PRIMARY KEY CLUSTERED 
(
	[PDPSelfAssessmentRecordPropertyValueId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[PDPSelfAssessmentRecords]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PDPSelfAssessmentRecords](
	[PDPSelfAssessmentRecordId] [nvarchar](450) NOT NULL,
	[Disabled] [bit] NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[PrimaryEntityId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_PDPSelfAssessmentRecords] PRIMARY KEY CLUSTERED 
(
	[PDPSelfAssessmentRecordId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Properties]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Properties](
	[PropertyId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[Name] [nvarchar](max) NULL,
	[PropertyTypeId] [bigint] NOT NULL,
	[PropertySubTypeId] [bigint] NULL,
 CONSTRAINT [PK_Properties] PRIMARY KEY CLUSTERED 
(
	[PropertyId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[PropertyChoices]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PropertyChoices](
	[PropertyChoiceId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[Text] [nvarchar](max) NULL,
	[PropertyId] [bigint] NOT NULL,
 CONSTRAINT [PK_PropertyChoices] PRIMARY KEY CLUSTERED 
(
	[PropertyChoiceId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[PropertySubTypes]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PropertySubTypes](
	[PropertySubTypeId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[Name] [nvarchar](max) NULL,
	[Description] [nvarchar](max) NULL,
	[PropertyTypeId] [bigint] NOT NULL,
 CONSTRAINT [PK_PropertySubTypes] PRIMARY KEY CLUSTERED 
(
	[PropertySubTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[PropertyTypes]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PropertyTypes](
	[PropertyTypeId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[Name] [nvarchar](max) NULL,
	[Description] [nvarchar](max) NULL,
 CONSTRAINT [PK_PropertyTypes] PRIMARY KEY CLUSTERED 
(
	[PropertyTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ReferenceRecordPropertyValues]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ReferenceRecordPropertyValues](
	[ReferenceRecordPropertyValueId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[ValueText] [nvarchar](max) NULL,
	[ValueDate] [datetime2](7) NULL,
	[ValueInt] [bigint] NULL,
	[ValueFloat] [real] NULL,
	[PropertyId] [bigint] NOT NULL,
	[ReferenceRecordId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_ReferenceRecordPropertyValues] PRIMARY KEY CLUSTERED 
(
	[ReferenceRecordPropertyValueId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ReferenceRecords]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ReferenceRecords](
	[ReferenceRecordId] [nvarchar](450) NOT NULL,
	[Disabled] [bit] NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[PrimaryEntityId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_ReferenceRecords] PRIMARY KEY CLUSTERED 
(
	[ReferenceRecordId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[RegulationPropertyValues]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[RegulationPropertyValues](
	[RegulationPropertyValueId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[ValueText] [nvarchar](max) NULL,
	[ValueDate] [datetime2](7) NULL,
	[ValueInt] [bigint] NULL,
	[ValueFloat] [real] NULL,
	[PropertyId] [bigint] NOT NULL,
	[RegulationId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_RegulationPropertyValues] PRIMARY KEY CLUSTERED 
(
	[RegulationPropertyValueId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Regulations]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Regulations](
	[RegulationId] [nvarchar](450) NOT NULL,
	[DisplayName] [nvarchar](max) NULL,
	[ExpireDateTime] [datetime2](7) NULL,
	[StartDateTime] [datetime2](7) NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[Disabled] [bit] NOT NULL,
	[UseRules] [bit] NOT NULL,
 CONSTRAINT [PK_Regulations] PRIMARY KEY CLUSTERED 
(
	[RegulationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Reminders]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Reminders](
	[ReminderId] [nvarchar](450) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[UserId] [nvarchar](450) NOT NULL,
	[ReminderType] [int] NOT NULL,
	[NumberOfReminders] [int] NOT NULL,
 CONSTRAINT [PK_Reminders] PRIMARY KEY CLUSTERED 
(
	[ReminderId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ReportRecordPropertyValues]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ReportRecordPropertyValues](
	[ReportRecordPropertyValueId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[ValueText] [nvarchar](max) NULL,
	[ValueDate] [datetime2](7) NULL,
	[ValueInt] [bigint] NULL,
	[ValueFloat] [real] NULL,
	[PropertyId] [bigint] NOT NULL,
	[ReportRecordId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_ReportRecordPropertyValues] PRIMARY KEY CLUSTERED 
(
	[ReportRecordPropertyValueId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ReportRecords]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ReportRecords](
	[ReportRecordId] [nvarchar](450) NOT NULL,
	[Disabled] [bit] NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[PrimaryEntityId] [nvarchar](450) NOT NULL,
	[ReportType] [bigint] NULL,
	[Status] [bigint] NULL,
 CONSTRAINT [PK_ReportRecords] PRIMARY KEY CLUSTERED 
(
	[ReportRecordId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ResumeRecordPropertyValues]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResumeRecordPropertyValues](
	[ResumeRecordPropertyValueId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[ValueText] [nvarchar](max) NULL,
	[ValueDate] [datetime2](7) NULL,
	[ValueInt] [bigint] NULL,
	[ValueFloat] [real] NULL,
	[PropertyId] [bigint] NOT NULL,
	[ResumeRecordId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_ResumeRecordPropertyValues] PRIMARY KEY CLUSTERED 
(
	[ResumeRecordPropertyValueId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ResumeRecords]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResumeRecords](
	[ResumeRecordId] [nvarchar](450) NOT NULL,
	[Disabled] [bit] NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[PrimaryEntityId] [nvarchar](450) NOT NULL,
	[IsGenerated] [bit] NOT NULL,
	[IsPublished] [bit] NOT NULL,
 CONSTRAINT [PK_ResumeRecords] PRIMARY KEY CLUSTERED 
(
	[ResumeRecordId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ResumeSectionEntities]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResumeSectionEntities](
	[ResumeSectionEntityId] [nvarchar](450) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[ResumeSectionId] [nvarchar](450) NOT NULL,
	[EntityId] [nvarchar](450) NOT NULL,
	[IsDisplayed] [bit] NOT NULL,
	[Sequence] [int] NOT NULL,
 CONSTRAINT [PK_ResumeSectionEntities] PRIMARY KEY CLUSTERED 
(
	[ResumeSectionEntityId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ResumeSections]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ResumeSections](
	[ResumeSectionId] [nvarchar](450) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[ResumeRecordId] [nvarchar](450) NOT NULL,
	[EntityTypeId] [bigint] NOT NULL,
	[IsDisplayed] [bit] NOT NULL,
	[Sequence] [int] NOT NULL,
 CONSTRAINT [PK_ResumeSections] PRIMARY KEY CLUSTERED 
(
	[ResumeSectionId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[RolePromotionActions]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[RolePromotionActions](
	[RolePromotionActionId] [nvarchar](450) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](450) NOT NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[OrganizationId] [nvarchar](450) NULL,
	[EmploymentRecordId] [nvarchar](450) NULL,
	[RoleId] [nvarchar](450) NULL,
	[ActionType] [int] NOT NULL,
	[Comments] [nvarchar](max) NULL,
	[ParentActionId] [nvarchar](450) NULL,
	[PrimaryEntityId] [nvarchar](450) NOT NULL,
	[Disabled] [bit] NOT NULL,
 CONSTRAINT [PK_RolePromotionActions] PRIMARY KEY CLUSTERED 
(
	[RolePromotionActionId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Rules]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Rules](
	[RuleId] [nvarchar](450) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[RegulationId] [nvarchar](450) NULL,
	[Disabled] [bit] NOT NULL,
	[Ambiguous] [bit] NOT NULL,
	[RuleText] [nvarchar](max) NULL,
	[Sequence] [int] NOT NULL,
	[FootnoteText] [nvarchar](max) NULL,
	[Hours] [int] NOT NULL,
	[MonthsToExpire] [int] NOT NULL,
 CONSTRAINT [PK_Rules] PRIMARY KEY CLUSTERED 
(
	[RuleId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SeedProperties]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SeedProperties](
	[SeedPropertyId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[SeedRecordId] [bigint] NOT NULL,
	[FormElementId] [bigint] NOT NULL,
	[Value] [nvarchar](max) NULL,
	[ValueInt] [bigint] NULL,
	[ValueFloat] [float] NULL,
	[ValueDate] [datetime2](7) NULL,
 CONSTRAINT [PK_SeedProperties] PRIMARY KEY CLUSTERED 
(
	[SeedPropertyId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SeedRecords]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SeedRecords](
	[SeedRecordId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[SeedName] [nvarchar](450) NOT NULL,
	[EntityTypeId] [bigint] NOT NULL,
 CONSTRAINT [PK_SeedRecords] PRIMARY KEY CLUSTERED 
(
	[SeedRecordId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TrainingCertificateRegens]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TrainingCertificateRegens](
	[TainingCertificateRegenId] [nvarchar](450) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[EnrollmentId] [nvarchar](max) NULL,
	[TrainingId] [nvarchar](max) NULL,
	[CerificateRegenStatus] [int] NOT NULL,
 CONSTRAINT [PK_TrainingCertificateRegens] PRIMARY KEY CLUSTERED 
(
	[TainingCertificateRegenId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TrainingRecordPropertyValues]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TrainingRecordPropertyValues](
	[TrainingRecordPropertyValueId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[ValueText] [nvarchar](max) NULL,
	[ValueDate] [datetime2](7) NULL,
	[ValueInt] [bigint] NULL,
	[ValueFloat] [real] NULL,
	[PropertyId] [bigint] NOT NULL,
	[TrainingRecordId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_TrainingRecordPropertyValues] PRIMARY KEY CLUSTERED 
(
	[TrainingRecordPropertyValueId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TrainingRecords]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TrainingRecords](
	[TrainingRecordId] [nvarchar](450) NOT NULL,
	[TrainingRecordName] [nvarchar](max) NULL,
	[EventCompletionDateTime] [datetime2](7) NOT NULL,
	[Disabled] [bit] NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[PrimaryEntityId] [nvarchar](450) NOT NULL,
	[TrainingOrganizationName] [nvarchar](max) NULL,
	[TrainerName] [nvarchar](max) NULL,
	[Trainer2Name] [nvarchar](max) NULL,
	[Trainer3Name] [nvarchar](max) NULL,
	[Trainer10Name] [nvarchar](max) NULL,
	[Trainer4Name] [nvarchar](max) NULL,
	[Trainer5Name] [nvarchar](max) NULL,
	[Trainer6Name] [nvarchar](max) NULL,
	[Trainer7Name] [nvarchar](max) NULL,
	[Trainer8Name] [nvarchar](max) NULL,
	[Trainer9Name] [nvarchar](max) NULL,
	[CourseRecordId] [nvarchar](450) NULL,
	[CourseSectionRecordId] [nvarchar](450) NULL,
	[PartnerId] [nvarchar](450) NULL,
 CONSTRAINT [PK_TrainingRecords] PRIMARY KEY CLUSTERED 
(
	[TrainingRecordId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TrainingRegulations]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TrainingRegulations](
	[TrainingRegulationId] [nvarchar](450) NOT NULL,
	[CourseRecordId] [nvarchar](450) NULL,
	[RegulationId] [nvarchar](450) NULL,
	[Status] [int] NOT NULL,
	[ExpireDateTime] [datetime2](7) NULL,
	[StartDateTime] [datetime2](7) NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[Disabled] [bit] NOT NULL,
 CONSTRAINT [PK_TrainingRegulations] PRIMARY KEY CLUSTERED 
(
	[TrainingRegulationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TrainingRules]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TrainingRules](
	[TrainingRuleId] [nvarchar](450) NOT NULL,
	[CourseRecordId] [nvarchar](450) NOT NULL,
	[RuleId] [nvarchar](450) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[Disabled] [bit] NOT NULL,
	[Ambiguous] [bit] NOT NULL,
 CONSTRAINT [PK_TrainingRules] PRIMARY KEY CLUSTERED 
(
	[TrainingRuleId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[UserMessages]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[UserMessages](
	[UserMessageId] [nvarchar](450) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[MessageGroupId] [nvarchar](max) NULL,
	[MessageParentId] [nvarchar](max) NULL,
	[Read] [bit] NOT NULL,
	[Starred] [bit] NOT NULL,
	[Archived] [bit] NOT NULL,
	[FromUserId] [nvarchar](450) NULL,
	[ToUserId] [nvarchar](450) NULL,
	[MessageContentId] [nvarchar](450) NULL,
	[MessageDistroGroup] [nvarchar](max) NULL,
 CONSTRAINT [PK_UserMessages] PRIMARY KEY CLUSTERED 
(
	[UserMessageId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[UserOrganizationRoles]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[UserOrganizationRoles](
	[UserOrganizationRoleId] [nvarchar](450) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[UserId] [nvarchar](450) NOT NULL,
	[OrganizationId] [nvarchar](450) NOT NULL,
	[RoleId] [nvarchar](450) NOT NULL,
	[Disabled] [bit] NOT NULL,
	[EmploymentRecordId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_UserOrganizationRoles] PRIMARY KEY CLUSTERED 
(
	[UserOrganizationRoleId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[UserPropertyValues]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[UserPropertyValues](
	[UserPropertyValueId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[ValueText] [nvarchar](max) NULL,
	[ValueDate] [datetime2](7) NULL,
	[ValueInt] [bigint] NULL,
	[ValueFloat] [real] NULL,
	[PropertyId] [bigint] NOT NULL,
	[UserId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_UserPropertyValues] PRIMARY KEY CLUSTERED 
(
	[UserPropertyValueId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[UserReferralPropertyValues]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[UserReferralPropertyValues](
	[UserReferralPropertyValueId] [bigint] IDENTITY(1,1) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[ValueText] [nvarchar](max) NULL,
	[ValueDate] [datetime2](7) NULL,
	[ValueInt] [bigint] NULL,
	[ValueFloat] [real] NULL,
	[PropertyId] [bigint] NOT NULL,
	[UserReferralId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_UserReferralPropertyValues] PRIMARY KEY CLUSTERED 
(
	[UserReferralPropertyValueId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[UserReferrals]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[UserReferrals](
	[UserReferralId] [nvarchar](450) NOT NULL,
	[Email] [nvarchar](max) NULL,
	[Disabled] [bit] NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[PrimaryEntityId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_UserReferrals] PRIMARY KEY CLUSTERED 
(
	[UserReferralId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[VerificationActions]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[VerificationActions](
	[VerificationActionId] [nvarchar](450) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](450) NOT NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[IsVerified] [bit] NOT NULL,
	[Comments] [nvarchar](max) NULL,
	[ParentActionVerificationActionId] [nvarchar](450) NULL,
	[VerificationId] [nvarchar](450) NOT NULL,
	[AgencyOrganizationId] [nvarchar](450) NULL,
	[ActionType] [int] NOT NULL,
	[Disabled] [bit] NOT NULL,
 CONSTRAINT [PK_VerificationActions] PRIMARY KEY CLUSTERED 
(
	[VerificationActionId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Verifications]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Verifications](
	[VerificationId] [nvarchar](450) NOT NULL,
	[EntityTypeId] [bigint] NOT NULL,
	[EntityId] [nvarchar](450) NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](450) NOT NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[Disabled] [bit] NOT NULL,
	[PrimaryEntityId] [nvarchar](450) NOT NULL,
	[AgencyOrganizationId] [nvarchar](450) NULL,
 CONSTRAINT [PK_Verifications] PRIMARY KEY CLUSTERED 
(
	[VerificationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ZipCodeRecords]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ZipCodeRecords](
	[ZipCodeRecordId] [nvarchar](450) NOT NULL,
	[Zip] [nvarchar](450) NOT NULL,
	[City] [nvarchar](max) NULL,
	[State] [nvarchar](max) NULL,
	[County] [nvarchar](max) NULL,
	[Disabled] [bit] NOT NULL,
	[CreationDateTime] [datetime2](7) NOT NULL,
	[LastChangeDateTime] [datetime2](7) NOT NULL,
	[CreationByUserId] [nvarchar](max) NULL,
	[LastChangeByUserId] [nvarchar](max) NULL,
	[SearchDisplayCity] [nvarchar](max) NULL,
 CONSTRAINT [PK_ZipCodeRecords] PRIMARY KEY CLUSTERED 
(
	[ZipCodeRecordId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [HangFire].[AggregatedCounter]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [HangFire].[AggregatedCounter](
	[Key] [nvarchar](100) NOT NULL,
	[Value] [bigint] NOT NULL,
	[ExpireAt] [datetime] NULL,
 CONSTRAINT [PK_HangFire_CounterAggregated] PRIMARY KEY CLUSTERED 
(
	[Key] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [HangFire].[Counter]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [HangFire].[Counter](
	[Key] [nvarchar](100) NOT NULL,
	[Value] [int] NOT NULL,
	[ExpireAt] [datetime] NULL
) ON [PRIMARY]
GO
/****** Object:  Table [HangFire].[Hash]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [HangFire].[Hash](
	[Key] [nvarchar](100) NOT NULL,
	[Field] [nvarchar](100) NOT NULL,
	[Value] [nvarchar](max) NULL,
	[ExpireAt] [datetime2](7) NULL,
 CONSTRAINT [PK_HangFire_Hash] PRIMARY KEY CLUSTERED 
(
	[Key] ASC,
	[Field] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [HangFire].[Job]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [HangFire].[Job](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[StateId] [bigint] NULL,
	[StateName] [nvarchar](20) NULL,
	[InvocationData] [nvarchar](max) NOT NULL,
	[Arguments] [nvarchar](max) NOT NULL,
	[CreatedAt] [datetime] NOT NULL,
	[ExpireAt] [datetime] NULL,
 CONSTRAINT [PK_HangFire_Job] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [HangFire].[JobParameter]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [HangFire].[JobParameter](
	[JobId] [bigint] NOT NULL,
	[Name] [nvarchar](40) NOT NULL,
	[Value] [nvarchar](max) NULL,
 CONSTRAINT [PK_HangFire_JobParameter] PRIMARY KEY CLUSTERED 
(
	[JobId] ASC,
	[Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [HangFire].[JobQueue]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [HangFire].[JobQueue](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[JobId] [bigint] NOT NULL,
	[Queue] [nvarchar](50) NOT NULL,
	[FetchedAt] [datetime] NULL,
 CONSTRAINT [PK_HangFire_JobQueue] PRIMARY KEY CLUSTERED 
(
	[Queue] ASC,
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [HangFire].[List]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [HangFire].[List](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[Key] [nvarchar](100) NOT NULL,
	[Value] [nvarchar](max) NULL,
	[ExpireAt] [datetime] NULL,
 CONSTRAINT [PK_HangFire_List] PRIMARY KEY CLUSTERED 
(
	[Key] ASC,
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [HangFire].[Schema]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [HangFire].[Schema](
	[Version] [int] NOT NULL,
 CONSTRAINT [PK_HangFire_Schema] PRIMARY KEY CLUSTERED 
(
	[Version] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [HangFire].[Server]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [HangFire].[Server](
	[Id] [nvarchar](100) NOT NULL,
	[Data] [nvarchar](max) NULL,
	[LastHeartbeat] [datetime] NOT NULL,
 CONSTRAINT [PK_HangFire_Server] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [HangFire].[Set]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [HangFire].[Set](
	[Key] [nvarchar](100) NOT NULL,
	[Score] [float] NOT NULL,
	[Value] [nvarchar](256) NOT NULL,
	[ExpireAt] [datetime] NULL,
 CONSTRAINT [PK_HangFire_Set] PRIMARY KEY CLUSTERED 
(
	[Key] ASC,
	[Value] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [HangFire].[State]    Script Date: 8/14/2024 9:16:10 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [HangFire].[State](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[JobId] [bigint] NOT NULL,
	[Name] [nvarchar](20) NOT NULL,
	[Reason] [nvarchar](100) NULL,
	[CreatedAt] [datetime] NOT NULL,
	[Data] [nvarchar](max) NULL,
 CONSTRAINT [PK_HangFire_State] PRIMARY KEY CLUSTERED 
(
	[JobId] ASC,
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[AspNetRoles] ADD  DEFAULT ((0)) FOR [Rank]
GO
ALTER TABLE [dbo].[EntityTypeProperties] ADD  DEFAULT (CONVERT([bit],(0))) FOR [HideInExport]
GO
ALTER TABLE [dbo].[FileInfo] ADD  DEFAULT (CONVERT([bit],(0))) FOR [IsStatic]
GO
ALTER TABLE [dbo].[FormElementChoices] ADD  DEFAULT (CONVERT([bigint],(0))) FOR [PropertyChoiceId]
GO
ALTER TABLE [dbo].[Forms] ADD  DEFAULT (CONVERT([bit],(0))) FOR [ExportCreatedBy]
GO
ALTER TABLE [dbo].[Forms] ADD  DEFAULT (CONVERT([bit],(0))) FOR [ExportCreatedDate]
GO
ALTER TABLE [dbo].[Forms] ADD  DEFAULT (CONVERT([bit],(0))) FOR [ExportLastUpdatedBy]
GO
ALTER TABLE [dbo].[Forms] ADD  DEFAULT (CONVERT([bit],(0))) FOR [ExportLastUpdatedDate]
GO
ALTER TABLE [dbo].[Notifications] ADD  DEFAULT (CONVERT([bit],(0))) FOR [Archived]
GO
ALTER TABLE [dbo].[Notifications] ADD  DEFAULT (CONVERT([bit],(0))) FOR [Read]
GO
ALTER TABLE [dbo].[Notifications] ADD  DEFAULT (CONVERT([bit],(0))) FOR [Starred]
GO
ALTER TABLE [dbo].[NotificationTriggers] ADD  DEFAULT (CONVERT([bit],(0))) FOR [SendEmail]
GO
ALTER TABLE [dbo].[Regulations] ADD  DEFAULT (CONVERT([bit],(0))) FOR [UseRules]
GO
ALTER TABLE [dbo].[ResumeRecords] ADD  DEFAULT (CONVERT([bit],(0))) FOR [IsGenerated]
GO
ALTER TABLE [dbo].[ResumeRecords] ADD  DEFAULT (CONVERT([bit],(0))) FOR [IsPublished]
GO
ALTER TABLE [dbo].[RolePromotionActions] ADD  DEFAULT (N'') FOR [PrimaryEntityId]
GO
ALTER TABLE [dbo].[RolePromotionActions] ADD  DEFAULT (CONVERT([bit],(0))) FOR [Disabled]
GO
ALTER TABLE [dbo].[Rules] ADD  DEFAULT ((0)) FOR [Hours]
GO
ALTER TABLE [dbo].[Rules] ADD  DEFAULT ((0)) FOR [MonthsToExpire]
GO
ALTER TABLE [dbo].[TrainingRules] ADD  DEFAULT (CONVERT([bit],(0))) FOR [Ambiguous]
GO
ALTER TABLE [dbo].[UserOrganizationRoles] ADD  DEFAULT (newid()) FOR [UserOrganizationRoleId]
GO
ALTER TABLE [dbo].[VerificationActions] ADD  DEFAULT ((1)) FOR [ActionType]
GO
ALTER TABLE [dbo].[VerificationActions] ADD  DEFAULT (CONVERT([bit],(0))) FOR [Disabled]
GO
